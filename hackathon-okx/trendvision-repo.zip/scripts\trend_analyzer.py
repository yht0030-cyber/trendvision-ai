"""
鹿希武趋势交易法 - 多周�?K线分析引�?
支持: 1H + 4H 双周期确�?
品种: XAUUSD (华尔街见�?, BTC/ETH (Gate.io)
"""

import json
import urllib.request
import sys
import os
import time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".factory", "skills"))
from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))
import ccxt
from datetime import datetime, timezone, timedelta

# ─── 配置 ───────────────────────────────────────────
WSCN_KLINE_URL = (
    "https://api-ddc-wscn.awtmt.com/market/kline"
    "?prod_code={symbol}&tick_count={count}&period={period}"
    "&fields=open_px,close_px,high_px,low_px"
)

MAX_QJT_THRESHOLD = 39  # 1H 线大 Qjt 标准（跨�?�?9 �?K 线为有效趋势结构�?

TIMEFRAME_CONFIG = {
    "1h": {"period": 3600, "count": 200},
    "4h": {"period": 14400, "count": 100},
}

SUPPORTED = {
    "XAUUSD": {"source": "wscn", "symbol": "XAUUSD"},
    "BTC": {"source": "gate", "pair": "BTC/USDT"},
    "ETH": {"source": "gate", "pair": "ETH/USDT"},
}

# ─── ccxt 交易所实例（延迟初始化，避免重复创建）─────
_gate_spot = None
_gate_swap = None


def _get_gate_spot():
    global _gate_spot
    if _gate_spot is None:
        _gate_spot = ccxt.gate()
    return _gate_spot


def _get_gate_swap():
    global _gate_swap
    if _gate_swap is None:
        _gate_swap = ccxt.gate({"options": {"defaultType": "swap"}})
    return _gate_swap


# ─── 数据拉取 ───────────────────────────────────────

def fetch_wscn(symbol, timeframe="1h"):
    """从华尔街见闻拉取 K �?[open, close, high, low]"""
    tf = TIMEFRAME_CONFIG[timeframe]
    url = WSCN_KLINE_URL.format(symbol=symbol, period=tf["period"], count=tf["count"])
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    data = json.loads(urllib.request.urlopen(req, timeout=15).read())
    lines = data["data"]["candle"][symbol]["lines"]
    candles = []
    for line in lines:
        if len(line) >= 4:
            candles.append({
                "open": float(line[0]), "close": float(line[1]),
                "high": float(line[2]), "low": float(line[3]),
            })
    preclose = data["data"]["candle"][symbol].get("pre_close_px", None)
    return candles, preclose


def fetch_gate(pair, timeframe="1h"):
    import urllib.request as _ur
    import json as _json
    tf = TIMEFRAME_CONFIG[timeframe]
    base, quote = pair.split("/")
    symbol = base + "_" + quote
    limit = tf["count"]
    url = "https://api.gateio.ws/api/v4/spot/candlesticks?currency_pair=" + symbol + "&interval=" + timeframe + "&limit=" + str(limit)
    req = _ur.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    raw = _ur.urlopen(req, timeout=15).read()
    data = _json.loads(raw)
    candles = []
    for r in data:
        candles.append({
            "ts": int(r[0]),
            "open": float(r[5]),
            "high": float(r[3]),
            "low": float(r[4]),
            "close": float(r[2]),
        })
    return candles, None


def fetch_contract_stats(pair):
    """�?Gate.io 拉取合约统计数据（资金费率、OI、多空比等）"""
    import urllib.request as _ur
    stats = {}
    
    # ccxt 资金费率（swap 格式�?
    try:
        ex = _get_gate_swap()
        swap_symbol = pair.replace("/", ":")  # BTC/USDT -> BTC/USDT:USDT
        funding = ex.fetch_funding_rate(swap_symbol)
        stats["funding_rate"] = funding
    except Exception:
        pass
    
    # OI / 多空�?/ 主动买卖�?�?REST API（ccxt �?Gate 支持有限�?
    try:
        base, quote = pair.split("/")
        contract = f"{base}_{quote}"
        url = (
            "https://api.gateio.ws/api/v4/futures/usdt/contract_stats"
            f"?contract={contract}&interval=1h&limit=1"
        )
        req = _ur.Request(url)
        data = json.loads(_ur.urlopen(req, timeout=10).read())
        if data:
            latest = data[0]
            stats["open_interest_usd"] = float(latest.get("open_interest_usd", 0))
            stats["lsr_taker"] = float(latest.get("lsr_taker", 1))
            stats["lsr_account"] = float(latest.get("lsr_account", 1))
            stats["long_rate"] = float(latest.get("long_rate", 0))
            stats["short_rate"] = float(latest.get("short_rate", 0))
    except Exception:
        pass
    
    return stats


def fetch_data(symbol, timeframe="1h"):
    """统一入口"""
    cfg = SUPPORTED.get(symbol.upper())
    if not cfg:
        raise ValueError(f"不支持品�? {symbol}，可�? {list(SUPPORTED.keys())}")
    src = cfg["source"]
    if src == "wscn":
        candles, preclose = fetch_wscn(cfg["symbol"], timeframe)
    else:
        candles, preclose = fetch_gate(cfg["pair"], timeframe)
    
    stats = None
    if src == "gate" and timeframe == "1h":
        try:
            stats = fetch_contract_stats(cfg["pair"])
        except Exception:
            pass
    
    return candles, preclose, stats


# ─── 指标计算 ───────────────────────────────────────

def calc_rsi(closes, period=9):
    """Simple RSI"""
    if len(closes) < period + 1:
        return []
    rsi_vals = []
    for end in range(period, len(closes)):
        changes = [closes[i] - closes[i-1] for i in range(end - period + 1, end + 1)]
        gains = sum(max(c, 0) for c in changes)
        losses = sum(abs(min(c, 0)) for c in changes)
        avg_gain = gains / period
        avg_loss = losses / period
        rs = avg_gain / avg_loss if avg_loss > 0 else float("inf")
        rsi = 100.0 if avg_loss == 0 else (100 - 100 / (1 + rs))
        rsi_vals.append(rsi)
    return rsi_vals


def calc_atr(candles, period=14):
    """Average True Range"""
    if len(candles) < period + 1:
        return []
    tr_vals = []
    for i in range(1, len(candles)):
        h, l = candles[i]["high"], candles[i]["low"]
        pc = candles[i-1]["close"]
        tr = max(h - l, abs(h - pc), abs(l - pc))
        tr_vals.append(tr)
    
    atr_vals = []
    sma = sum(tr_vals[:period]) / period
    atr_vals.append(sma)
    for i in range(period, len(tr_vals)):
        sma = (sma * (period - 1) + tr_vals[i]) / period
        atr_vals.append(sma)
    return atr_vals


# ─── RSI 背离检�?─────────────────────────────────────

def detect_rsi_divergence(candles, swings, rsi_vals, rsi_offset=8):
    """
    RSI 背离检测：
    - 顶背离：价格新高 RSI 未新�?�?上升趋势减弱警告
    - 底背离：价格新低 RSI 未新�?�?下降趋势减弱警告
    rsi_offset: RSI 对应价格索引的偏移（RSI[index] 对应 price[index+rsi_offset]�?
    """
    if not rsi_vals or len(rsi_vals) < 10:
        return []

    divs = []
    period = len(candles) - len(rsi_vals)  # RSI lag

    # 找价格的高点和低�?
    highs = sorted([s for s in swings if s["type"] == "high"], key=lambda x: x["idx"])
    lows = sorted([s for s in swings if s["type"] == "low"], key=lambda x: x["idx"])

    def _rsi_at(idx):
        ri = idx - period
        if 0 <= ri < len(rsi_vals):
            return rsi_vals[ri]
        return None

    # 顶背离：两个上升的高点，价格更高�?RSI 更低
    for i in range(len(highs) - 1):
        h1, h2 = highs[i], highs[i + 1]
        if h2["price"] > h1["price"]:
            r1 = _rsi_at(h1["idx"])
            r2 = _rsi_at(h2["idx"])
            if r1 is not None and r2 is not None and r2 < r1 - 5:  # RSI 低了至少5�?
                divs.append({
                    "type": "bearish",
                    "desc": "顶背�?,
                    "price1": round(h1["price"], 2), "price2": round(h2["price"], 2),
                    "rsi1": round(r1, 1), "rsi2": round(r2, 1),
                    "detail": f"价格新高{h2['price']:.1f}>{h1['price']:.1f} 但RSI {r2:.1f}<{r1:.1f} �?上升动能减弱",
                })

    # 底背离：两个下降的低点，价格更低�?RSI 更高
    for i in range(len(lows) - 1):
        l1, l2 = lows[i], lows[i + 1]
        if l2["price"] < l1["price"]:
            r1 = _rsi_at(l1["idx"])
            r2 = _rsi_at(l2["idx"])
            if r1 is not None and r2 is not None and r2 > r1 + 5:
                divs.append({
                    "type": "bullish",
                    "desc": "底背�?,
                    "price1": round(l1["price"], 2), "price2": round(l2["price"], 2),
                    "rsi1": round(r1, 1), "rsi2": round(r2, 1),
                    "detail": f"价格新低{l2['price']:.1f}<{l1['price']:.1f} 但RSI {r2:.1f}>{r1:.1f} �?下跌动能减弱",
                })

    return divs


# ─── 拐点识别 ───────────────────────────────────────

def find_swings(candles, lookback=3):
    """识别近期主要拐点 (swing highs & lows)"""
    swings = []
    n = len(candles)
    for i in range(lookback, n - lookback):
        c = candles[i]
        window_highs = [candles[j]["high"] for j in range(i-lookback, i+lookback+1) if j != i]
        window_lows = [candles[j]["low"] for j in range(i-lookback, i+lookback+1) if j != i]
        
        if c["high"] > max(window_highs):
            swings.append({"type": "high", "idx": i, "price": c["high"]})
        if c["low"] < min(window_lows):
            swings.append({"type": "low", "idx": i, "price": c["low"]})
    
    return swings


# ─── 区间跨度 Qjt ────────────────────────────────────

def classify_pair(q1, q2):
    """按书中规则归类两个区间的关系"""
    if q1 <= 10 and q2 <= 10:
        dif = q2 - q1
        if -2 <= dif <= 2:    return "同级�?
        elif 3 <= dif <= 5:   return "扩张"
        elif -5 <= dif <= -3: return "收缩"
        elif 6 <= dif <= 8:   return "升级"
        elif -8 <= dif <= -6: return "降级"
        return None
    else:
        if q1 <= 0: q1 = 1
        d = q2 / q1
        if 0.828 <= d <= 1.208:     return "同级�?
        elif 1.208 < d <= 2.618:    return "扩张"
        elif 0.382 <= d < 0.828:    return "收缩"
        elif d > 2.618:             return "升级"
        elif d < 0.382:             return "降级"
        return None

def calc_qjt(candles):
    """Qjt 区间跨度 �?按鹿希武《趋势交易法》第3版第三章实现

    核心规则（书中原文）�?
    - 上升区间：价格创出新高，到再次创出新高并收市于新高之上的周期
    - 下降区间：价格创出新低，到再次创出新低并收市于新低之下的周期
    - �?区间需收市确认，第2+区间突破即算
    - 区间是交替的：↑ �?�?�?�?�?（不能连续两个同向区间）
    - 外区间包含内区间，内区间不单独算

    v2 改进�?026-07-08）：
    - 改为交替推进模式，修复趋势转向检测漏下降区间的问�?
    - 增加嵌套去重逻辑
    """
    n = len(candles)
    swings = find_swings(candles, lookback=3)

    highs = [s for s in swings if s["type"] == "high"]
    lows = [s for s in swings if s["type"] == "low"]

    if not highs or not lows:
        return {
            "high": {}, "low": {},
            "high_intervals": [], "low_intervals": [],
            "high_pairs": [], "low_pairs": [],
        }

    high_intervals = []
    low_intervals = []

    # ── 确定起始方向 ──
    # 如果第一个摆动是高点，先走↑方向；第一个是低点，先走↓方向
    hi, li = 0, 0
    if highs[0]["idx"] < lows[0]["idx"]:
        ref = highs[0]
        direction = "up"
        hi = 1
    else:
        ref = lows[0]
        direction = "down"
        li = 1

    is_first_up = True
    is_first_down = True

    # ── 交替推进 ──
    while True:
        if direction == "up":
            found = False
            while hi < len(highs):
                if highs[hi]["price"] > ref["price"]:
                    if is_first_up:
                        confirmed = False
                        for j in range(ref["idx"] + 1, highs[hi]["idx"] + 1):
                            if candles[j]["close"] > ref["price"]:
                                confirmed = True
                                break
                        if not confirmed:
                            hi += 1
                            continue
                        is_first_up = False
                    high_intervals.append({
                        "idx": ref["idx"], "price": ref["price"],
                        "broken_idx": highs[hi]["idx"],
                        "qjt": highs[hi]["idx"] - ref["idx"]
                    })
                    ref = highs[hi]
                    hi += 1
                    direction = "down"
                    found = True
                    break
                hi += 1
            if not found:
                break
        else:  # down
            found = False
            while li < len(lows):
                if lows[li]["price"] < ref["price"]:
                    if is_first_down:
                        confirmed = False
                        for j in range(ref["idx"] + 1, lows[li]["idx"] + 1):
                            if candles[j]["close"] < ref["price"]:
                                confirmed = True
                                break
                        if not confirmed:
                            li += 1
                            continue
                        is_first_down = False
                    low_intervals.append({
                        "idx": ref["idx"], "price": ref["price"],
                        "broken_idx": lows[li]["idx"],
                        "qjt": lows[li]["idx"] - ref["idx"]
                    })
                    ref = lows[li]
                    li += 1
                    direction = "up"
                    found = True
                    break
                li += 1
            if not found:
                break

    # ── 嵌套去重：外区间包含内区间时，舍内保�?──
    def dedup_nested(items):
        if len(items) < 2:
            return items
        srt = sorted(items, key=lambda x: x["idx"])
        result = []
        for item in srt:
            # 是否被已有区间包�?
            contained = False
            for existing in result:
                if (existing["idx"] <= item["idx"] and
                        existing["broken_idx"] >= item["broken_idx"]):
                    contained = True
                    break
            if not contained:
                # 是否包含已有区间（保大舍小）
                result = [e for e in result if not
                    (item["idx"] <= e["idx"] and item["broken_idx"] >= e["broken_idx"])]
                result.append(item)
        return result

    high_intervals = dedup_nested(high_intervals)
    low_intervals = dedup_nested(low_intervals)

    # ── �?dif/δ 归类并分�?──
    def group_intervals(items):
        if len(items) < 2:
            return [], []
        srt = sorted(items, key=lambda x: x["idx"])
        pairs = []
        for i in range(len(srt) - 1):
            label = classify_pair(srt[i]["qjt"], srt[i + 1]["qjt"])
            if label:
                pairs.append({"from": srt[i], "to": srt[i + 1], "rel": label})
        groups = []
        cur = []
        for p in pairs:
            cur.append(p)
            if p is not pairs[-1]:
                continue
            groups.append([x for x in cur])
            cur = []
        return pairs, groups

    high_pairs, high_groups = group_intervals(high_intervals)
    low_pairs, low_groups = group_intervals(low_intervals)

    # ── 4. 趋势结构总结 ──
    def summarize(items, pairs, groups):
        if not items:
            return {}
        vals = [x["qjt"] for x in sorted(items, key=lambda x: x["idx"])]
        latest_pair = pairs[-1] if pairs else None
        latest_group = groups[-1] if groups else []
        max_qjt = max(vals) if vals else 0
        return {
            "count": len(items),
            "vals": vals,
            "max": max_qjt,
            "latest_pair": latest_pair,
            "latest_group": latest_group,
            "pairs": pairs,
            "groups": groups,
        }

    return {
        "high": summarize(high_intervals, high_pairs, high_groups),
        "low": summarize(low_intervals, low_pairs, low_groups),
        "high_intervals": high_intervals,
        "low_intervals": low_intervals,
        "high_pairs": high_pairs,
        "low_pairs": low_pairs,
    }


# ─── 波浪计数 ───────────────────────────────────────

def count_waves(swings, candles_len):
    """基于拐点做简易波浪计�?- 覆盖全周�?""
    if len(swings) < 4:
        return None, None
    
    # 找连续的高低转折点（全量�?
    waves = []
    last_type = None
    for s in swings:
        if s["type"] != last_type:
            waves.append(s)
            last_type = s["type"]
    
    if len(waves) < 4:
        return None, None
    
    # 判断趋势：取最�?个高点和最�?个低点，比方向（2026-06-20 二次修复�?
    # 旧版均值法含远古高/低点，看不见近期趋势转向�?
    # 直接�?adjacent swing high/low：h[-1] vs h[-2], l[-1] vs l[-2]
    highs = [w for w in waves if w["type"] == "high"]
    lows = [w for w in waves if w["type"] == "low"]

    if len(highs) < 2 or len(lows) < 2:
        return waves, "unknown"

    h2, h1 = highs[-2]["price"], highs[-1]["price"]   # 前高，后�?
    l2, l1 = lows[-2]["price"], lows[-1]["price"]      # 前低，后�?

    h_rising = h1 > h2
    h_falling = h1 < h2
    l_rising = l1 > l2
    l_falling = l1 < l2

    if h_rising and l_rising:
        trend = "up"
    elif h_falling and l_falling:
        trend = "down"
    else:
        trend = "sideways"
    
    return waves, trend


# ─── 趋势线（按第3版第五章重写）─────────────────────

def is_standard_kline(c, candles=None, lookback=40, top_n=5):
    """
    标准K�?�?按第3版第四章定义�?
    取最�?lookback 根K线中最大的 top_n 根，计算均值�?
    阳线: close-low > 均�?�?标准K�?
    阴线: high-close > 均�?�?标准K�?
    """
    body = abs(c["open"] - c["close"])
    total = c["high"] - c["low"]
    if total == 0:
        return False, 0

    # 如果提供�?candles 上下文，用动态阈�?
    threshold = 0
    if candles:
        ctx = candles[-min(lookback, len(candles)):]
        if len(ctx) >= top_n:
            vals = []
            for k in ctx:
                if k["close"] >= k["open"]:
                    vals.append(k["close"] - k["low"])
                else:
                    vals.append(k["high"] - k["close"])
            vals.sort(reverse=True)
            threshold = sum(vals[:top_n]) / top_n

    is_bull = c["close"] >= c["open"]
    if is_bull:
        val = c["close"] - c["low"]
    else:
        val = c["high"] - c["close"]

    is_std = val > threshold if threshold > 0 else (body / total >= 0.4)
    return is_std, round(val, 2)


def _line_val(p1_idx, p1_price, p2_idx, p2_price, idx):
    """计算趋势线在 idx 位置的�?""
    slope = (p2_price - p1_price) / (p2_idx - p1_idx)
    return p1_price + slope * (idx - p1_idx)


def _validate_tl(candles, p1_idx, p1_price, p2_idx, p2_price, tl_type):
    """验证趋势线中间不穿越任何价位（第五章第三节）�?
    允许个别假高/低点（书允许过滤消息面造成的假高低点）�?
    最多允�?span �?5%（最�?1 个）微小穿越（穿越幅�?< ATR*0.15）�?
    """
    if p2_idx - p1_idx <= 1:
        return True

    # 计算 ATR 用于穿越容忍�?
    tr_vals = []
    for i in range(p1_idx + 1, p2_idx + 1):
        c = candles[i]
        prev = candles[i - 1]
        tr = max(c["high"] - c["low"], abs(c["high"] - prev["close"]), abs(c["low"] - prev["close"]))
        tr_vals.append(tr)
    avg_tr = sum(tr_vals) / len(tr_vals) if tr_vals else 0

    span = p2_idx - p1_idx
    max_crossings = max(1, int(span * 0.05))  # 5% tolerance
    crossing_count = 0

    for i in range(p1_idx + 1, p2_idx):
        lv = _line_val(p1_idx, p1_price, p2_idx, p2_price, i)
        c = candles[i]
        if tl_type == "uptrend":
            if lv > c["low"]:
                penetration = lv - c["low"]
                if penetration > avg_tr * 0.15:  # 穿越超过 15% ATR �?真穿�?
                    return False
                crossing_count += 1
        else:
            if lv < c["high"]:
                penetration = c["high"] - lv
                if penetration > avg_tr * 0.15:
                    return False
                crossing_count += 1

    return crossing_count <= max_crossings


def find_trendline(candles, swings, qjt_result=None):
    """识别趋势�?�?按第3版第五章规则�?

    上升趋势线：连接最低点（或相对低点）与最高点之前的调整浪低点
    下降趋势线：连接最高点（或相对高点）与最低点之前的调整浪高点
    核心约束：P2 必须在趋势极值点之前，中间不穿越任何价位�?

    选择策略：综�?span 长度、触点数、价格支�?压制效果评分�?
    而非单纯最�?span（旧版）或单纯全局极值锚定（第一版重写）�?
    """
    highs = [s for s in swings if s["type"] == "high"]
    lows = [s for s in swings if s["type"] == "low"]
    n = len(candles)

    global_high_idx = max(range(n), key=lambda i: candles[i]["high"])
    global_low_idx = min(range(n), key=lambda i: candles[i]["low"])
    global_high_price = candles[global_high_idx]["high"]
    global_low_price = candles[global_low_idx]["low"]

    candidates = []

    # ── 上升趋势线候�?──
    # 枚举所�?swing low 对，P2 必须�?P1 之后、全局最高点之前、价格高�?P1
    for i in range(len(lows)):
        l1 = lows[i]
        for j in range(i + 1, len(lows)):
            l2 = lows[j]
            if l2["price"] <= l1["price"]:
                continue
            if l2["idx"] >= global_high_idx:
                continue
            if not _validate_tl(candles, l1["idx"], l1["price"],
                               l2["idx"], l2["price"], "uptrend"):
                continue

            span = l2["idx"] - l1["idx"]
            slope = (l2["price"] - l1["price"]) / span
            cur = _line_val(l1["idx"], l1["price"], l2["idx"], l2["price"], n - 1)

            # 触点评分：统�?P1→P2 之间有多�?swing low 被此线支�?
            touch_count = 0
            for sl in lows:
                if l1["idx"] < sl["idx"] < l2["idx"]:
                    lv = _line_val(l1["idx"], l1["price"],
                                   l2["idx"], l2["price"], sl["idx"])
                    if sl["price"] >= lv * 0.998:
                        touch_count += 1

            # 价格支撑效果：统�?P1→P2 之间有多�?K 线最低价被支�?
            support_bars = 0
            for k in range(l1["idx"] + 1, l2["idx"]):
                lv = _line_val(l1["idx"], l1["price"],
                               l2["idx"], l2["price"], k)
                if candles[k]["low"] >= lv * 0.995:
                    support_bars += 1

            # 综合评分：span 是基础，触�?支撑加成
            score = span * (1 + touch_count * 1.0 + max(0, support_bars / span - 0.5) * 2.0)

            candidates.append({
                "type": "uptrend",
                "p1": {"idx": l1["idx"], "price": round(l1["price"], 2)},
                "p2": {"idx": l2["idx"], "price": round(l2["price"], 2)},
                "span": span, "slope": slope,
                "current_value": round(cur, 2),
                "touch_count": touch_count,
                "score": score,
            })

    # ── 下降趋势线候�?──
    for i in range(len(highs)):
        h1 = highs[i]
        for j in range(i + 1, len(highs)):
            h2 = highs[j]
            if h2["price"] >= h1["price"]:
                continue
            if h2["idx"] >= global_low_idx:
                continue
            if not _validate_tl(candles, h1["idx"], h1["price"],
                               h2["idx"], h2["price"], "downtrend"):
                continue

            span = h2["idx"] - h1["idx"]
            slope = (h2["price"] - h1["price"]) / span
            cur = _line_val(h1["idx"], h1["price"], h2["idx"], h2["price"], n - 1)

            # 触点评分
            touch_count = 0
            for sh in highs:
                if h1["idx"] < sh["idx"] < h2["idx"]:
                    lv = _line_val(h1["idx"], h1["price"],
                                   h2["idx"], h2["price"], sh["idx"])
                    if sh["price"] <= lv * 1.002:
                        touch_count += 1

            # 价格压制效果
            resist_bars = 0
            for k in range(h1["idx"] + 1, h2["idx"]):
                lv = _line_val(h1["idx"], h1["price"],
                               h2["idx"], h2["price"], k)
                if candles[k]["high"] <= lv * 1.005:
                    resist_bars += 1

            score = span * (1 + touch_count * 1.0 + max(0, resist_bars / span - 0.5) * 2.0)

            candidates.append({
                "type": "downtrend",
                "p1": {"idx": h1["idx"], "price": round(h1["price"], 2)},
                "p2": {"idx": h2["idx"], "price": round(h2["price"], 2)},
                "span": span, "slope": slope,
                "current_value": round(cur, 2),
                "touch_count": touch_count,
                "score": score,
            })

    if not candidates:
        return None

    # 选最佳候选：综合评分
    best = max(candidates, key=lambda r: r["score"])

    # ── 突破检�?──
    if best["type"] == "uptrend":
        best["broken"] = candles[-1]["close"] < best["current_value"]
    else:
        best["broken"] = candles[-1]["close"] > best["current_value"]

    # ── 突破分类（直接转�?/ 延时转向）──
    if best["broken"]:
        bc = candles[-1]
        best["break_is_standard"] = is_standard_kline(bc, candles)[0]

        # 距离极�?
        if best["type"] == "uptrend":
            extreme_idx = global_low_idx
        else:
            extreme_idx = global_high_idx
        best["break_far"] = (n - 1 - extreme_idx) > 30

        # 三段延时判断（书5.4节）
        if not best["break_is_standard"]:
            best["turn_type"] = "延时转向"
            best["turn_reason"] = "非标准K线突破（十字�?锤子等），等2根确�?
        elif best["break_far"]:
            best["turn_type"] = "延时转向"
            best["turn_reason"] = "突破点距极值过远、止损过大，等调整浪再入�?
        else:
            # 检�?2%~78.6%回撤区（�?.4节第3条）
            break_in_retrace = False
            if best["type"] == "uptrend":
                wave_high = global_high_price
                wave_low = global_low_price
                wave_range = wave_high - wave_low
                if wave_range > 0:
                    retrace = (wave_high - candles[-1]["close"]) / wave_range
                    break_in_retrace = 0.62 <= retrace <= 0.786
            else:
                wave_high = global_high_price
                wave_low = global_low_price
                wave_range = wave_high - wave_low
                if wave_range > 0:
                    retrace = (candles[-1]["close"] - wave_low) / wave_range
                    break_in_retrace = 0.62 <= retrace <= 0.786

            if break_in_retrace:
                best["turn_type"] = "延时转向"
                best["turn_reason"] = "突破K线落�?2%~78.6%回撤区，即使标准K线也延时"
            else:
                best["turn_type"] = "直接转向"
                best["turn_reason"] = "标准K线突�?+ 距极值近，可立即转向"
    else:
        best["turn_type"] = None

    # ── 主趋�?/ 导航趋势线（�?Qjt δ 判定，书5.2节）──
    if qjt_result:
        hi_intervals = qjt_result.get("high_intervals", [])
        lo_intervals = qjt_result.get("low_intervals", [])
        if best["type"] == "uptrend":
            if hi_intervals and lo_intervals:
                cur_max = max(x["qjt"] for x in hi_intervals)
                prev_last = lo_intervals[-1]["qjt"]
                if prev_last > 0:
                    d = cur_max / prev_last
                    best["tl_level"] = "主趋势趋势线" if 0.828 <= d <= 1.208 else "导航趋势�?
                    best["tl_delta"] = round(d, 2)
                    best["tl_cur_max_qjt"] = cur_max
                    best["tl_prev_last_qjt"] = prev_last
                else:
                    best["tl_level"] = "导航趋势�?
            else:
                best["tl_level"] = "导航趋势�?
        elif best["type"] == "downtrend":
            if lo_intervals and hi_intervals:
                cur_max = max(x["qjt"] for x in lo_intervals)
                prev_last = hi_intervals[-1]["qjt"]
                if prev_last > 0:
                    d = cur_max / prev_last
                    best["tl_level"] = "主趋势趋势线" if 0.828 <= d <= 1.208 else "导航趋势�?
                    best["tl_delta"] = round(d, 2)
                    best["tl_cur_max_qjt"] = cur_max
                    best["tl_prev_last_qjt"] = prev_last
                else:
                    best["tl_level"] = "导航趋势�?
            else:
                best["tl_level"] = "导航趋势�?
    else:
        best["tl_level"] = "导航趋势�?

    # 清理评分用的临时字段
    best.pop("touch_count", None)
    best.pop("score", None)

    return best


# ─── 拐点线（按第3版第六章实现）────────────────────

def find_channel(candles, swings, qjt_result=None):
    """
    拐点�?= 外延线的平行线�?
    口诀：要找下，先画上；要找上，先画下�?
    - 上升趋势：先画上方外延线（连2+高点，包含所有价格），平行下移至�?低点
    - 下降趋势：先画下方外延线（连2+低点，包含所有价格），平行上移至�?高点
    �?Qjt 区分趋势拐点�?/ 导航拐点线�?
    """
    highs = [s for s in swings if s["type"] == "high"]
    lows = [s for s in swings if s["type"] == "low"]
    n = len(candles)

    results = []

    # ── 上升趋势拐点线（要找下，先画上）──
    if len(highs) >= 2:
        for i in range(len(highs)):
            for j in range(i + 1, len(highs)):
                h1, h2 = highs[i], highs[j]
                if h2["idx"] <= h1["idx"]:
                    continue
                # 外延线斜�?
                span = h2["idx"] - h1["idx"]
                if span < 2:
                    continue
                slope = (h2["price"] - h1["price"]) / span

                # 验证：所有价格必须在外延线之下（不穿越）
                valid = True
                for k in range(h1["idx"], n):
                    lv = h1["price"] + slope * (k - h1["idx"])
                    if candles[k]["high"] > lv + 1e-9:  # 有价格穿�?
                        valid = False
                        break
                if not valid:
                    continue

                # 找两锚点之间最低的 swing low（≈ �?低点�?
                mid_lows = [l for l in lows if h1["idx"] < l["idx"] < h2["idx"]]
                if not mid_lows:
                    continue
                wave2_low = min(mid_lows, key=lambda x: x["price"])

                # 拐点�?= �?wave2_low 的平行线
                chan_slope = slope
                chan_intercept = wave2_low["price"] - chan_slope * wave2_low["idx"]
                cur_chan = chan_intercept + chan_slope * (n - 1)

                results.append({
                    "type": "uptrend",
                    "outer_p1": {"idx": h1["idx"], "price": round(h1["price"], 2)},
                    "outer_p2": {"idx": h2["idx"], "price": round(h2["price"], 2)},
                    "channel_pivot": {"idx": wave2_low["idx"], "price": round(wave2_low["price"], 2)},
                    "span": span, "slope": round(slope, 6),
                    "current_value": round(cur_chan, 2),
                })

    # ── 下降趋势拐点线（要找上，先画下）──
    if len(lows) >= 2:
        for i in range(len(lows)):
            for j in range(i + 1, len(lows)):
                l1, l2 = lows[i], lows[j]
                if l2["idx"] <= l1["idx"]:
                    continue
                span = l2["idx"] - l1["idx"]
                if span < 2:
                    continue
                slope = (l2["price"] - l1["price"]) / span

                # 验证：所有价格必须在外延线之�?
                valid = True
                for k in range(l1["idx"], n):
                    lv = l1["price"] + slope * (k - l1["idx"])
                    if candles[k]["low"] < lv - 1e-9:
                        valid = False
                        break
                if not valid:
                    continue

                mid_highs = [h for h in highs if l1["idx"] < h["idx"] < l2["idx"]]
                if not mid_highs:
                    continue
                wave2_high = max(mid_highs, key=lambda x: x["price"])

                cur_chan = wave2_high["price"] + slope * (n - 1 - wave2_high["idx"])

                results.append({
                    "type": "downtrend",
                    "outer_p1": {"idx": l1["idx"], "price": round(l1["price"], 2)},
                    "outer_p2": {"idx": l2["idx"], "price": round(l2["price"], 2)},
                    "channel_pivot": {"idx": wave2_high["idx"], "price": round(wave2_high["price"], 2)},
                    "span": span, "slope": round(slope, 6),
                    "current_value": round(cur_chan, 2),
                })

    if not results:
        return None

    # 选外延线跨度最大的
    best = max(results, key=lambda r: r["span"])

    # ── 突破检�?──
    if best["type"] == "uptrend":
        best["broken"] = candles[-1]["close"] < best["current_value"]
    else:
        best["broken"] = candles[-1]["close"] > best["current_value"]

    # ── 突破分类 ──
    if best["broken"]:
        bc = candles[-1]
        best["break_is_standard"] = is_standard_kline(bc, candles)[0]
        if best["type"] == "uptrend":
            extreme_idx = min(range(n), key=lambda i: candles[i]["low"])
        else:
            extreme_idx = max(range(n), key=lambda i: candles[i]["high"])
        best["break_far"] = (n - 1 - extreme_idx) > 30

        if not best["break_is_standard"]:
            best["turn_type"] = "延时转向"
            best["turn_reason"] = "非标准K线突破拐点线，等2根确�?
        elif best["break_far"]:
            best["turn_type"] = "延时转向"
            best["turn_reason"] = "突破点距极值过远，止损过大"
        else:
            best["turn_type"] = "直接转向"
            best["turn_reason"] = "标准K线突破拐点线 + 距极值近"
    else:
        best["turn_type"] = None

    # ── 趋势拐点�?/ 导航拐点线（Qjt δ 判定，书6.3节）──
    if qjt_result:
        hi_intervals = qjt_result.get("high_intervals", [])
        lo_intervals = qjt_result.get("low_intervals", [])
        if best["type"] == "uptrend":
            if hi_intervals and lo_intervals:
                cur_max = max(x["qjt"] for x in hi_intervals)
                prev_last = lo_intervals[-1]["qjt"]
                if prev_last > 0:
                    d = cur_max / prev_last
                    best["channel_level"] = "趋势拐点�? if 0.828 <= d <= 1.208 else "导航拐点�?
                    best["channel_delta"] = round(d, 2)
            else:
                best["channel_level"] = "导航拐点�?
        elif best["type"] == "downtrend":
            if lo_intervals and hi_intervals:
                cur_max = max(x["qjt"] for x in lo_intervals)
                prev_last = hi_intervals[-1]["qjt"]
                if prev_last > 0:
                    d = cur_max / prev_last
                    best["channel_level"] = "趋势拐点�? if 0.828 <= d <= 1.208 else "导航拐点�?
                    best["channel_delta"] = round(d, 2)
            else:
                best["channel_level"] = "导航拐点�?

    return best


# ─── 分界�?A（按�?版第七章重写）─────────────────

def find_pivot_a(candles, swings, qjt_result=None, trend=None):
    """
    分界点A = 调整浪的结束点。基�?Qjt 区间定位�?
    - 两个连续上升区间之间的最低点 �?分界点A（上升趋势）
    - 两个连续下降区间之间的最高点 �?分界点A（下降趋势）
    - 同级�?扩张/收缩 �?主趋势A；升�?降级 �?导航A
    """
    n = len(candles)
    result = {"main_a": None, "nav_a": None, "all_a": []}

    if not qjt_result:
        return _fallback_pivot_a(swings, trend, result)

    hi_intervals = qjt_result.get("high_intervals", [])
    lo_intervals = qjt_result.get("low_intervals", [])

    # ── 上升趋势�?A 点：连续上升区间之间的最低点 ──
    hi_sorted = sorted(hi_intervals, key=lambda x: x["idx"])
    for i in range(1, len(hi_sorted)):
        prev, curr = hi_sorted[i - 1], hi_sorted[i]
        zs, ze = prev["broken_idx"], curr["idx"]
        if ze < zs:  # 首尾相接(broken_idx==idx)仍可找单�?
            continue
        lo_idx = min(range(zs, min(ze + 1, n)), key=lambda k: candles[k]["low"])
        rel = classify_pair(prev["qjt"], curr["qjt"]) or "未知"
        entry = {
            "type": "low", "idx": lo_idx,
            "price": round(candles[lo_idx]["low"], 2),
            "a_kind": rel,
            "qjt_from": prev["qjt"], "qjt_to": curr["qjt"],
        }
        result["all_a"].append(entry)

    # ── 下降趋势�?A 点：连续下降区间之间的最高点 ──
    lo_sorted = sorted(lo_intervals, key=lambda x: x["idx"])
    for i in range(1, len(lo_sorted)):
        prev, curr = lo_sorted[i - 1], lo_sorted[i]
        zs, ze = prev["broken_idx"], curr["idx"]
        if ze < zs:
            continue
        hi_idx = max(range(zs, min(ze + 1, n)), key=lambda k: candles[k]["high"])
        rel = classify_pair(prev["qjt"], curr["qjt"]) or "未知"
        entry = {
            "type": "high", "idx": hi_idx,
            "price": round(candles[hi_idx]["high"], 2),
            "a_kind": rel,
            "qjt_from": prev["qjt"], "qjt_to": curr["qjt"],
        }
        result["all_a"].append(entry)

    # 按时间排序取最�?
    result["all_a"].sort(key=lambda p: p["idx"], reverse=True)
    main = [p for p in result["all_a"] if p["a_kind"] in ("同级�?, "扩张", "收缩")]
    nav = [p for p in result["all_a"] if p["a_kind"] in ("升级", "降级")]

    result["main_a"] = main[0] if main else None
    result["nav_a"] = nav[0] if nav else None

    # 若没�?Qjt 得出�?A 点，fallback
    if not result["main_a"] and not result["nav_a"]:
        return _fallback_pivot_a(swings, trend, result)

    return result


def _fallback_pivot_a(swings, trend, result):
    """fallback：取倒数第二个反向拐�?""
    if not swings:
        return result
    if trend == "down":
        highs = [s for s in swings if s["type"] == "high"]
        if len(highs) >= 2:
            fallback = highs[-2]
            result["main_a"] = {"type": "high", "idx": fallback["idx"],
                                "price": round(fallback["price"], 2), "a_kind": "fallback"}
    else:
        lows = [s for s in swings if s["type"] == "low"]
        if len(lows) >= 2:
            fallback = lows[-2]
            result["main_a"] = {"type": "low", "idx": fallback["idx"],
                                "price": round(fallback["price"], 2), "a_kind": "fallback"}
    return result


# ─── 波浪结构分类 & PSTD 目标位（�?版第八章）─────────

def classify_trend_structure(qjt_result):
    """
    基于 Qjt 区间分类趋势结构�?种）及反转概率�?
    返回: { "structure": "同级�?�?, "reversal_pct": 78, "detail": "..." }
    """
    hi = qjt_result.get("high_intervals", [])
    lo = qjt_result.get("low_intervals", [])
    result = {"uptrend": None, "downtrend": None}

    def _classify(items):
        if len(items) < 2:
            return None
        vals = [x["qjt"] for x in sorted(items, key=lambda x: x["idx"])]
        pairs = []
        for i in range(len(vals) - 1):
            pairs.append(classify_pair(vals[i], vals[i + 1]))

        if len(vals) == 2:
            if pairs[0] == "同级�?:
                return {"structure": "同级�?�?, "reversal_pct": 78,
                        "qjt_vals": vals, "pairs": pairs,
                        "detail": "2个同级别区间，反转概�?8%"}
            elif pairs[0] == "扩张":
                return {"structure": "扩张5浪（未完成）", "reversal_pct": None,
                        "qjt_vals": vals, "pairs": pairs,
                        "detail": "扩张趋势中，等待�?区间确认7�?}
            elif pairs[0] == "收缩":
                return {"structure": "收缩5浪（未完成）", "reversal_pct": None,
                        "qjt_vals": vals, "pairs": pairs,
                        "detail": "收缩趋势中，等待�?区间确认7�?}
            return None

        if len(vals) >= 3:
            p1, p2 = pairs[0], pairs[1]
            if p1 == "扩张" and p2 in ("同级�?, "扩张"):
                return {"structure": "扩张7�?, "reversal_pct": 89,
                        "qjt_vals": vals[:3], "pairs": pairs[:2],
                        "detail": f"Q1={vals[0]}→Q2={vals[1]}(扩张)→Q3={vals[2]}({p2})，反转概�?9%"}
            if p1 == "收缩" and p2 in ("同级�?, "收缩"):
                return {"structure": "收缩7�?, "reversal_pct": 89,
                        "qjt_vals": vals[:3], "pairs": pairs[:2],
                        "detail": f"Q1={vals[0]}→Q2={vals[1]}(收缩)→Q3={vals[2]}({p2})，反转概�?9%"}
            if p1 == "扩张" and p2 == "收缩":
                return {"structure": "钻石7�?, "reversal_pct": 89,
                        "qjt_vals": vals[:3], "pairs": pairs[:2],
                        "detail": f"Q1={vals[0]}→Q2={vals[1]}(扩张)→Q3={vals[2]}(收缩)，反转概�?9%"}
            if p1 == "收缩" and p2 == "扩张":
                return {"structure": "X7�?, "reversal_pct": 89,
                        "qjt_vals": vals[:3], "pairs": pairs[:2],
                        "detail": f"Q1={vals[0]}→Q2={vals[1]}(收缩)→Q3={vals[2]}(扩张)，反转概�?9%"}
            return None

    result["uptrend"] = _classify(hi)
    result["downtrend"] = _classify(lo)
    return result


# ─── 数浪法则 4~8（第3版第八章第五节）─────────────────

def _wave_height(candles, si, ei, direction):
    """计算区间内主浪高度（含内部极端点�?""
    if si >= ei or si >= len(candles) or ei >= len(candles):
        return 0
    seg = candles[si:ei + 1]
    if direction == "up":
        lo = min(c["low"] for c in seg)
        hi = max(c["high"] for c in seg)
    else:
        hi = max(c["high"] for c in seg)
        lo = min(c["low"] for c in seg)
    return abs(hi - lo)


def apply_wave_rules(candles, qjt_result):
    """
    应用数浪法则 4~8 �?Qjt 区间，返回增强的波浪规则诊断�?
    - 法则4: 先内后外（内外区间层级处理）
    - 法则5: 区间合并 Hp > 1.618 × Ha
    - 法则6: �?可超�?
    - 法则7: 升级 δ > 2.618
    - 法则8: 降级 δ < 0.382
    """
    hi_intervals = sorted(qjt_result.get("high_intervals", []), key=lambda x: x["idx"])
    lo_intervals = sorted(qjt_result.get("low_intervals", []), key=lambda x: x["idx"])
    n = len(candles)

    rules = {"high": [], "low": [], "summary": []}

    def _analyze(items, direction):
        results = []
        if len(items) < 2:
            return results

        vals = [x["qjt"] for x in items]

        # ── 法则 4: 先内后外 ──
        # 检查每个外区间是否包含内区间（价格在区间范围内形成更小级别的拐点）
        for i in range(len(items)):
            cur = items[i]
            inner_ranges = []
            for j in range(len(items)):
                if i == j:
                    continue
                other = items[j]
                # 内区间：other 完全�?cur 范围内，且更晚开�?
                if other["idx"] > cur["idx"] and other["broken_idx"] < cur.get("broken_idx", n):
                    inner_ranges.append({"qjt": other["qjt"], "pos": j})
            if inner_ranges:
                results.append({
                    "rule": "法则4(先内后外)",
                    "desc": f"第{i+1}区间(Qjt={vals[i]})内含{len(inner_ranges)}个内区间，先满足内区间结�?,
                    "outer_idx": i,
                    "inner_count": len(inner_ranges),
                    "action": "先分析内区间结构完整性，再处理外区间"
                })

        # ── 法则 5: 区间合并 Hp > 1.618 × Ha ──
        for i in range(len(items) - 1):
            prev, curr = items[i], items[i + 1]
            hp = _wave_height(candles, curr["idx"], curr.get("broken_idx", n - 1), direction)
            ha = _wave_height(candles, prev["idx"], prev.get("broken_idx", n - 1), direction)
            if ha > 0 and hp > 1.618 * ha:
                results.append({
                    "rule": "法则5(区间合并)",
                    "desc": f"Hp({hp:.1f}) > 1.618×Ha({ha:.1f})，合并第{i+1}和{i+2}区间",
                    "pair": (i, i + 1),
                    "hp": round(hp, 2), "ha": round(ha, 2), "ratio": round(hp / ha, 2),
                    "action": "合并区间重新计数"
                })

        # ── 法则 6: �?可超�? ──
        if len(items) >= 2 and direction == "up":
            # �? = �?区间, �? = �?区间破位到第2区间之间的低�?
            w1 = items[0]
            w1_lo = min(candles[k]["low"] for k in range(w1["idx"], min(w1.get("broken_idx", n - 1) + 1, n)))
            # 检查后续是否出现比�?低点更低的低�?
            for j in range(w1.get("broken_idx", n - 1) + 1, min(items[-1].get("broken_idx", n - 1) + 1, n)):
                if candles[j]["low"] < w1_lo:
                    results.append({
                        "rule": "法则6(�?可超�?)",
                        "desc": f"�?低点({candles[j]['low']:.2f}) < �?低点({w1_lo:.2f})，只要结构满足即�?,
                        "action": "不必因浪2低于�?而否定趋�?
                    })
                    break
        elif len(items) >= 2 and direction == "down":
            w1 = items[0]
            w1_hi = max(candles[k]["high"] for k in range(w1["idx"], min(w1.get("broken_idx", n - 1) + 1, n)))
            for j in range(w1.get("broken_idx", n - 1) + 1, min(items[-1].get("broken_idx", n - 1) + 1, n)):
                if candles[j]["high"] > w1_hi:
                    results.append({
                        "rule": "法则6(�?可超�?)",
                        "desc": f"�?高点({candles[j]['high']:.2f}) > �?高点({w1_hi:.2f})，只要结构满足即�?,
                        "action": "不必因浪2高于�?而否定趋�?
                    })
                    break

        # ── 法则 7: 升级 δ > 2.618 ──
        for i in range(1, len(items)):
            q1, q2 = vals[i - 1], vals[i]
            if q1 > 0 and q2 / q1 > 2.618:
                results.append({
                    "rule": "法则7(升级)",
                    "desc": f"δ=Q{i+1}/Q{i}={q2}/{q1}={q2/q1:.2f} > 2.618，之前所有浪合并为一个大�?,
                    "pair": (i - 1, i),
                    "delta": round(q2 / q1, 2),
                    "action": "合并前{i+1}个区间重新计数，新的�?开�?
                })

        # ── 法则 8: 降级 δ < 0.382 ──
        for i in range(1, len(items)):
            q1, q2 = vals[i - 1], vals[i]
            if q1 > 0 and q2 / q1 < 0.382:
                results.append({
                    "rule": "法则8(降级)",
                    "desc": f"δ=Q{i+1}/Q{i}={q2}/{q1}={q2/q1:.2f} < 0.382，新区间降级为子�?,
                    "pair": (i - 1, i),
                    "delta": round(q2 / q1, 2),
                    "action": "对当前浪进行扩延数浪，寻找内区间"
                })

        return results

    rules["high"] = _analyze(hi_intervals, "up")
    rules["low"] = _analyze(lo_intervals, "down")

    # ── 汇�?──
    all_rules = rules["high"] + rules["low"]
    if not all_rules:
        rules["summary"].append("�?数浪法则4~8检查通过，无特殊规则触发")
    else:
        for r in all_rules:
            rules["summary"].append(f"[{r['rule']}] {r['desc']}")
        if any(r["rule"].startswith("法则7") or r["rule"].startswith("法则8") for r in all_rules):
            rules["summary"].append("�?触发升级/降级法则，可能需重新数浪�?)

    return rules


def calc_pstd_targets(candles, qjt_result, trend_direction):
    """
    PSTD 主浪目标位计算：基于�?高度预测�?/5/7目标�?
    """
    n = len(candles)
    hi = sorted(qjt_result.get("high_intervals", []), key=lambda x: x["idx"])
    lo = sorted(qjt_result.get("low_intervals", []), key=lambda x: x["idx"])

    targets = {"wave1_height": None, "targets": [], "full_targets": [], "direction": None}

    if trend_direction == "up" and hi:
        first = hi[0]
        si, ei = first["idx"], first["broken_idx"]
        if ei > si and ei < n:
            sp = min(candles[k]["low"] for k in range(si, ei + 1))
            ep = candles[ei]["high"]
            h1 = ep - sp
            if h1 > 0:
                targets["wave1_height"] = round(h1, 2)
                targets["wave1_start"] = round(sp, 2)
                targets["targets"] = [round(sp + m * h1, 2) for m in [1.208, 1.618, 2.000, 2.382, 2.618, 3.000]]
                targets["full_targets"] = [round(sp + m * h1, 2) for m in [3.236, 4.236]]
                targets["direction"] = "up"

    elif trend_direction == "down" and lo:
        first = lo[0]
        si, ei = first["idx"], first["broken_idx"]
        if ei > si and ei < n:
            sp = max(candles[k]["high"] for k in range(si, ei + 1))
            ep = candles[ei]["low"]
            h1 = sp - ep
            if h1 > 0:
                targets["wave1_height"] = round(h1, 2)
                targets["wave1_start"] = round(sp, 2)
                targets["targets"] = [round(sp - m * h1, 2) for m in [1.208, 1.618, 2.000, 2.382, 2.618, 3.000]]
                targets["full_targets"] = [round(sp - m * h1, 2) for m in [3.236, 4.236]]
                targets["direction"] = "down"

    return targets


# ─── 缓冲�?──────────────────────────────────────────

# ─── 斐波那契回调位计�?──────────────────────────────

def calc_retracements(candles, qjt_result):
    """
    计算每个主浪�?40%/62%/78.6% 回调入场区�?
    基于书中 "�?0买卖规则" 和浪2/�?回调位�?
    """
    n = len(candles)
    hi_intervals = sorted(qjt_result.get("high_intervals", []), key=lambda x: x["idx"])
    lo_intervals = sorted(qjt_result.get("low_intervals", []), key=lambda x: x["idx"])
    all_waves = []

    def _wave_range(start_idx, end_idx, direction):
        """获取主浪的价格范�?""
        if start_idx >= end_idx or end_idx >= n:
            return 0, 0
        seg = candles[start_idx:end_idx + 1]
        if direction == "up":
            return min(c["low"] for c in seg), max(c["high"] for c in seg)
        else:
            return max(c["high"] for c in seg), min(c["low"] for c in seg)

    def _retrace_levels(hi, lo, direction):
        """计算回调位：40%, 62%, 78.6%"""
        rng = abs(hi - lo)
        if rng == 0:
            return {}
        if direction == "up":
            return {
                "40%": round(hi - rng * 0.400, 2),
                "62%": round(hi - rng * 0.620, 2),
                "78.6%": round(hi - rng * 0.786, 2),
            }
        else:
            return {
                "40%": round(lo + rng * 0.400, 2),
                "62%": round(lo + rng * 0.620, 2),
                "78.6%": round(lo + rng * 0.786, 2),
            }

    # 上升趋势：每个上升区�?= 一个主�?
    for i, iv in enumerate(hi_intervals):
        w_start = iv["idx"]
        w_end = iv.get("broken_idx", n - 1)
        lo_px, hi_px = _wave_range(w_start, w_end, "up")
        if lo_px == 0 and hi_px == 0:
            continue
        retrace = _retrace_levels(hi_px, lo_px, "up")
        all_waves.append({
            "dir": "up", "num": i + 1, "qjt": iv["qjt"],
            "start_idx": w_start, "end_idx": w_end,
            "low": round(lo_px, 2), "high": round(hi_px, 2),
            "range": round(hi_px - lo_px, 2),
            "retrace": retrace,
        })

    # 下降趋势：每个下降区�?= 一个主�?
    for i, iv in enumerate(lo_intervals):
        w_start = iv["idx"]
        w_end = iv.get("broken_idx", n - 1)
        hi_px, lo_px = _wave_range(w_start, w_end, "down")
        if lo_px == 0 and hi_px == 0:
            continue
        retrace = _retrace_levels(hi_px, lo_px, "down")
        all_waves.append({
            "dir": "down", "num": i + 1, "qjt": iv["qjt"],
            "start_idx": w_start, "end_idx": w_end,
            "high": round(hi_px, 2), "low": round(lo_px, 2),
            "range": round(hi_px - lo_px, 2),
            "retrace": retrace,
        })

    return all_waves


# ─── Tp/Ta 判定（第3版第八章第四节）─────────────────────

def calc_tp_ta(candles, qjt_result, swings):
    """
    Tp/Ta 判定：后浪是否调整浪的概率�?
    - Tp = 后浪时间跨度（相邻主浪间的周期）
    - Ta = 前浪时间跨度（调整浪周期�?
    - Tp/Ta �?1.208 �?后浪为调整浪大概率（后浪慢于前浪�?
    - 三角形调整浪中不启用�?
    """
    n = len(candles)
    hi_intervals = sorted(qjt_result.get("high_intervals", []), key=lambda x: x["idx"])
    lo_intervals = sorted(qjt_result.get("low_intervals", []), key=lambda x: x["idx"])
    results = []

    def _calc(items, direction):
        res = []
        for i in range(1, len(items)):
            prev, curr = items[i - 1], items[i]
            # Tp = curr 时间跨度, Ta = prev 时间跨度
            tp = curr["qjt"]
            ta = prev["qjt"]
            if ta == 0:
                continue
            ratio = tp / ta
            is_adjust = ratio >= 1.208
            # Tp = Ta*0.828 is the minimum period
            res.append({
                "dir": direction,
                "pair_idx": (i, i + 1),
                "ta": ta, "tp": tp,
                "ratio": round(ratio, 2),
                "is_adjustment_likely": is_adjust,
                "desc": f"Tp/Ta={ratio:.2f} {'�? if is_adjust else '<'} 1.208 �?{'后浪大概率是调整�? if is_adjust else '后浪正常为主�?}",
            })
        return res

    results = _calc(hi_intervals, "up") + _calc(lo_intervals, "down")
    return results


# ─── 斐波那契周期跟踪 ──────────────────────────────────

FIB_PERIODS = [3, 5, 8, 13, 21, 34, 55]

def fib_cycle_track(qjt_result):
    """
    跟踪各区间的 Qjt 值距离斐波那契周期的接近程度�?
    趋势常在 3/5/8/13/21/34/55 个周期完成�?
    """
    hi_intervals = sorted(qjt_result.get("high_intervals", []), key=lambda x: x["idx"])
    lo_intervals = sorted(qjt_result.get("lo_intervals", []), key=lambda x: x["idx"]) if qjt_result.get("lo_intervals") else sorted(qjt_result.get("low_intervals", []), key=lambda x: x["idx"])

    def _track(items, direction):
        res = []
        for iv in items:
            qjt = iv["qjt"]
            closest = min(FIB_PERIODS, key=lambda f: abs(f - qjt))
            dist = qjt - closest
            if abs(dist) <= 2:  # within ±2 of a fib number
                res.append({
                    "dir": direction,
                    "qjt": qjt,
                    "near_fib": closest,
                    "offset": dist,
                    "note": f"Qjt={qjt} �?斐波 {closest} ({'+' if dist>0 else ''}{dist})",
                })
        return res

    return _track(hi_intervals, "up") + _track(lo_intervals, "down")


# ─── 仓位计算�?──────────────────────────────────────────

def calc_position(total_capital, stop_points, leverage=1, contract_value=1):
    """
    仓位计算�?�?按第3版第十章资金管理规则�?
    - 总风险金 = 总资�?× 30%
    - 每笔最大亏�?= 总风险金 ÷ 10
    - 仓位 = 每笔最大亏�?÷ 止损点数
    """
    risk_capital = total_capital * 0.30
    per_trade_risk = risk_capital / 10.0
    position = per_trade_risk / max(stop_points, 0.01)
    return {
        "total_capital": total_capital,
        "risk_capital": round(risk_capital, 2),
        "per_trade_risk": round(per_trade_risk, 2),
        "stop_points": stop_points,
        "position_size": round(position, 4),
        "leverage": leverage,
        "margin_required": round(position * contract_value / leverage, 2) if leverage > 1 else None,
        "risk_warning": None if per_trade_risk <= risk_capital * 0.1 else "单笔风险超过总风险金�?0%!",
    }


def buffer_analysis(candles):
    closes = [c["close"] for c in candles]
    highs = [c["high"] for c in candles]
    lows = [c["low"] for c in candles]
    
    all_high = max(highs)
    all_low = min(lows)
    current = closes[-1]
    total_range = all_high - all_low
    
    # 价值区 = 中位�?+/- 1 标准差（剔除离群值后�?
    sorted_closes = sorted(closes)
    n = len(sorted_closes)
    median = sorted_closes[n // 2]
    q1 = sorted_closes[n // 4]
    q3 = sorted_closes[3 * n // 4]
    iqr = q3 - q1
    filtered = [x for x in closes if q1 - 1.5 * iqr <= x <= q3 + 1.5 * iqr]
    
    if len(filtered) >= 10:
        mean_f = sum(filtered) / len(filtered)
        variance = sum((x - mean_f) ** 2 for x in filtered) / len(filtered)
        std = variance ** 0.5
    else:
        mean_f = sum(closes) / n
        variance = sum((x - mean_f) ** 2 for x in closes) / n
        std = variance ** 0.5
    
    value_area_high = median + std
    value_area_low = median - std
    
    # 支撑/阻力�?
    supports = []
    resistances = []
    
    # 铁底铁顶
    supports.append({"level": round(all_low, 2), "label": "铁底 (200根最�?"})
    resistances.append({"level": round(all_high, 2), "label": "铁顶 (200根最�?"})
    
    # 价值区上下�?
    supports.append({"level": round(value_area_low, 2), "label": "价值区下沿"})
    resistances.append({"level": round(value_area_high, 2), "label": "价值区上沿"})
    
    # 当前价格定位
    pct = (current - all_low) / total_range * 100 if total_range > 0 else 50
    
    # 大单方向
    sorted_by_range = sorted(candles, key=lambda c: c["high"] - c["low"], reverse=True)[:10]
    big_bear = sum(1 for c in sorted_by_range if c["close"] < c["open"])
    big_bull = sum(1 for c in sorted_by_range if c["close"] >= c["open"])
    
    return {
        "current": round(current, 2),
        "range_high": round(all_high, 2),
        "range_low": round(all_low, 2),
        "total_range": round(total_range, 2),
        "position_pct": round(pct, 1),
        "value_area": f"{value_area_low:.1f} - {value_area_high:.1f}",
        "supports": supports,
        "resistances": resistances,
        "big_volume_bias": "空头主导" if big_bear > big_bull else "多头主导" if big_bull > big_bear else "均衡",
    }


# ─── K线形态识�?────────────────────────────────────

def detect_candle_patterns(candles):
    """识别最近K线的反转形�?�?按第3版第四章"""
    n = len(candles)
    if n < 3:
        return []
    
    patterns = []
    scope = range(max(1, n - 8), n)  # 最�?�?

    for i in scope:
        c = candles[i]
        prev = candles[i-1] if i > 0 else None
        prev2 = candles[i-2] if i > 1 else None
        prev3 = candles[i-3] if i > 2 else None

        body = abs(c["open"] - c["close"])
        upper = c["high"] - max(c["open"], c["close"])
        lower = min(c["open"], c["close"]) - c["low"]
        total = c["high"] - c["low"]
        is_bull = c["close"] >= c["open"]
        is_bear = c["close"] < c["open"]

        if total == 0:
            continue

        body_pct = body / total
        is_std, std_val = is_standard_kline(c, candles)

        # ── 十字星（区分看涨/看跌）──
        if body_pct < 0.1 and total > 0:
            if upper > lower * 2:
                patterns.append({"type": "doji_bear", "idx": i, "desc": "看跌十字星（上影>>下影�?})
            elif lower > upper * 2:
                patterns.append({"type": "doji_bull", "idx": i, "desc": "看涨十字星（下影>>上影�?})
            else:
                patterns.append({"type": "doji", "idx": i, "desc": "十字星（等待方向确认�?})

        # ── 锤子�?/ 倒锤子线（书：影�?> 1.618×实体，且必须为标准K线）──
        if body > 0 and is_std:
            if lower > body * 1.618 and upper < body * 0.5:
                patterns.append({"type": "hammer", "idx": i, "desc": "锤子�?�?底部反转"})
            if upper > body * 1.618 and lower < body * 0.5:
                patterns.append({"type": "shooting_star", "idx": i, "desc": "倒锤子线 �?顶部反转"})

        # ── 标准K线标�?──
        if is_std:
            patterns.append({"type": "std_kline", "idx": i, "desc": f"标准K�?val={std_val})"})

        # ── 二根K线形�?──
        if prev:
            prev_body = abs(prev["open"] - prev["close"])
            prev_bull = prev["close"] >= prev["open"]
            prev_total = prev["high"] - prev["low"]

            # 吞没（严格大�?+ 后一根必须为标准K线）
            if is_bull and not prev_bull and body > prev_body and is_std:
                if c["open"] < prev["close"] and c["close"] > prev["open"]:
                    patterns.append({"type": "bullish_engulfing", "idx": i, "desc": "阳抱�?★★ 强烈反转"})
            if is_bear and prev_bull and body > prev_body and is_std:
                if c["open"] > prev["close"] and c["close"] < prev["open"]:
                    patterns.append({"type": "bearish_engulfing", "idx": i, "desc": "阴抱�?★★ 强烈反转"})

            # 补缺影线：后一根实体完全覆盖前一根影线（后一根需标准K线）
            if prev_total > 0 and body > 0 and is_std:
                # 上补缺（看涨�?
                if is_bull and prev["high"] > prev["open"] and prev["high"] > prev["close"]:
                    if c["close"] > prev["high"]:
                        patterns.append({"type": "gap_fill_up", "idx": i, "desc": "上补缺影�?�?看涨"})
                # 下补缺（看跌�?
                if is_bear and prev["low"] < prev["open"] and prev["low"] < prev["close"]:
                    if c["close"] < prev["low"]:
                        patterns.append({"type": "gap_fill_down", "idx": i, "desc": "下补缺影�?�?看跌"})

            # 魂断蓝桥：光头对光脚 �?光脚对光头（后一根需标准K线）
            p_upper = prev["high"] - max(prev["open"], prev["close"])
            p_lower = min(prev["open"], prev["close"]) - prev["low"]
            # 光头对光脚（看涨）：前一根无上影+后一根无下影
            if p_upper < body * 0.1 and lower < body * 0.1 and is_bull and is_std:
                patterns.append({"type": "hdsq", "idx": i, "desc": "魂断蓝桥（光头对光脚）★ 看涨"})
            # 光脚对光头（看跌）：前一根无下影+后一根无上影
            if p_lower < body * 0.1 and upper < body * 0.1 and is_bear and is_std:
                patterns.append({"type": "hdsq_bear", "idx": i, "desc": "魂断蓝桥（光脚对光头）★ 看跌"})

            # 跳空
            gap_pct = abs(c["open"] - prev["close"]) / prev["close"] if prev["close"] > 0 else 0
            if gap_pct > 0.002:  # >0.2% 视为跳空
                if c["open"] > prev["close"]:
                    patterns.append({"type": "gap_up", "idx": i, "desc": f"跳空高开({gap_pct*100:.1f}%)"})
                else:
                    patterns.append({"type": "gap_down", "idx": i, "desc": f"跳空低开({gap_pct*100:.1f}%)"})

        # ── 三根K线形�?──
        if prev2 and prev:
            p2_bull = prev2["close"] >= prev2["open"]
            p2_body = abs(prev2["open"] - prev2["close"])

            # 启明星：�?+ 小K + 标准�?�?阳收�?> 阴中�?
            if not p2_bull and not (prev_bull or prev.get("close") == prev.get("open")) and is_bull and is_std:
                mid = (prev2["open"] + prev2["close"]) / 2
                if c["close"] > mid:
                    patterns.append({"type": "morning_star", "idx": i, "desc": "启明�?★★ 底部反转"})

            # 黄昏星：�?+ 小K + 标准�?�?阴收�?< 阳中�?
            if p2_bull and not (prev_bull or prev.get("close") == prev.get("open")) and is_bear and is_std:
                mid = (prev2["open"] + prev2["close"]) / 2
                if c["close"] < mid:
                    patterns.append({"type": "evening_star", "idx": i, "desc": "黄昏�?★★ 顶部反转"})

            # 鬼门关：标准K + 十字�?小K + 反向标准K
            p2_std, _ = is_standard_kline(prev2, candles)
            p2_small = abs(prev2["open"] - prev2["close"]) / max(prev2["high"] - prev2["low"], 0.0001) < 0.15
            if p2_std and p2_small and is_std and p2_bull != is_bull:
                patterns.append({"type": "ghost_gate", "idx": i, "desc": "鬼门�?★★�?极强反转"})

            # 急停加速：标准K + 小K + 同向标准K
            if p2_std and p2_small and is_std and p2_bull == is_bull:
                direction = "看涨" if is_bull else "看跌"
                patterns.append({"type": "stop_accel", "idx": i, "desc": f"急停加�?★★ {direction}"})

            # 阳阴�?/ 阴阳�?确认（最后根需标准K线）
            if p2_bull and not prev_bull and is_bull and is_std:
                patterns.append({"type": "yiny_yang", "idx": i, "desc": "阳阴�?�?看涨确认"})
            if not p2_bull and prev_bull and is_bear and is_std:
                patterns.append({"type": "yang_yiny", "idx": i, "desc": "阴阳�?�?看跌确认"})

        # ── 海底捞月：前2根内创新�?高又收回（当根需标准K线）──
        if prev and prev2 and is_std:
            if c["low"] < prev2["low"] and is_bull and c["close"] > prev["close"]:
                patterns.append({"type": "bottom_fish", "idx": i, "desc": "海底捞月 �?底部确立"})
            if c["high"] > prev2["high"] and is_bear and c["close"] < prev["close"]:
                patterns.append({"type": "top_fish", "idx": i, "desc": "海底捞月（顶）★ 顶部确立"})

        # ── 三影线：�?根长影线（同方向）──
        if i >= 2 and prev and prev2:
            up_count = sum(1 for k in [candles[i-2], candles[i-1], c]
                          if (k["high"] - max(k["open"], k["close"])) > abs(k["open"] - k["close"]) * 2)
            lo_count = sum(1 for k in [candles[i-2], candles[i-1], c]
                          if (min(k["open"], k["close"]) - k["low"]) > abs(k["open"] - k["close"]) * 2)
            if up_count >= 3:
                patterns.append({"type": "three_up_shadows", "idx": i, "desc": "三上影线 �?顶部压力"})
            if lo_count >= 3:
                patterns.append({"type": "three_down_shadows", "idx": i, "desc": "三下影线 �?底部支撑"})

    return patterns


SIGNAL_MAX_SCORE = 10  # 价格2 + RSI1 + 形�? + 拐点�? + A�? + 趋势�?


def score_from_window(window, trend_4h=None):
    """从一段K线窗口构建评分所需的最小分析上下文并调�?evaluate_signal�?
    回测与实盘共用此入口，确保评分逻辑完全一致�?""
    if not window or len(window) < 20:
        return None
    closes = [c["close"] for c in window]
    rsi9 = calc_rsi(closes, 9)
    atr_vals = calc_atr(window, 14)
    swings = find_swings(window)
    qjt = calc_qjt(window)
    r = {
        "current_price": closes[-1],
        "rsi9": round(rsi9[-1], 1) if rsi9 else None,
        "atr14": round(atr_vals[-1], 2) if atr_vals else None,
        "trendline": find_trendline(window, swings, qjt),
        "channel": find_channel(window, swings, qjt),
        "pivot_a": find_pivot_a(window, swings, qjt, count_waves(swings, len(window))[1]),
        "buffer": buffer_analysis(window),
    }
    return evaluate_signal(r, window, trend_4h=trend_4h)


def evaluate_signal(r, candles, trend_4h=None):
    """量化信号评分（满�?0�?

    入场择时(基础)：价格位�? + RSI1 + K线形�?
    系统工具方向确认(回测权重)：拐点线3 + 分界点A1 + 趋势�?
      拐点线回测准确率最�?81-93%)，故权重最大；趋势线偏弱，权重最低�?
      规则十四：趋势线+A点同向突�?= 最强信号，额外加成�?
    trend_4h: 若提供，启用 4H 方向过滤——�?4H 大方向的触发被否决（只做顺势）�?
    """
    if not candles:
        return None
    
    current = r["current_price"]
    atr = r.get("atr14", 10) or 10
    rsi = r.get("rsi9")
    buf = r["buffer"]
    patterns = detect_candle_patterns(candles)
    
    # ── 基础择时条件 ──
    # 条件 1: 价格位置
    va_parts = buf["value_area"].split(" - ")
    va_low = float(va_parts[0]) if len(va_parts) == 2 else current - atr
    va_high = float(va_parts[1]) if len(va_parts) == 2 else current + atr
    
    at_support = current <= va_low + atr  # 价格在支撑区
    at_resistance = current >= va_high - atr  # 价格在阻力区
    
    # 条件 2: RSI 位置
    rsi_oversold_recovering = rsi is not None and 30 <= rsi <= 55
    rsi_overbought_cooling = rsi is not None and 45 <= rsi <= 70
    
    # 条件 3: K线形�?
    bull_patterns = [p for p in patterns if p["type"] in (
        "hammer", "bullish_engulfing", "morning_star", "gap_fill_up",
        "hdsq", "doji_bull", "bottom_fish", "three_down_shadows", "stop_accel",
        "yiny_yang", "ghost_gate"
    ) and len(candles) - p["idx"] <= 3]
    bear_patterns = [p for p in patterns if p["type"] in (
        "shooting_star", "bearish_engulfing", "evening_star", "gap_fill_down",
        "hdsq_bear", "doji_bear", "top_fish", "three_up_shadows",
        "yang_yiny", "ghost_gate"
    ) and len(candles) - p["idx"] <= 3]
    has_bull_pattern = len(bull_patterns) > 0
    has_bear_pattern = len(bear_patterns) > 0
    
    # ── 系统工具方向确认 ──
    tl = r.get("trendline")
    ch = r.get("channel")
    pa = r.get("pivot_a")
    tool_bull = 0
    tool_bear = 0
    tool_notes_bull = []
    tool_notes_bear = []
    
    # 拐点线突破（回测最强，权重3�?
    if ch and ch.get("broken"):
        if ch.get("type") == "downtrend":      # 下降拐点线被�?�?转多
            tool_bull += 3; tool_notes_bull.append("拐点线突破↑")
        elif ch.get("type") == "uptrend":      # 上升拐点线被�?�?转空
            tool_bear += 3; tool_notes_bear.append("拐点线跌破↓")
    
    # 分界点A 突破（权�?�?
    a_bull = a_bear = False
    if pa and pa.get("main_a"):
        ma = pa["main_a"]
        if ma.get("type") == "high" and current > ma["price"]:
            a_bull = True; tool_bull += 1; tool_notes_bull.append("A点突破↑")
        elif ma.get("type") == "low" and current < ma["price"]:
            a_bear = True; tool_bear += 1; tool_notes_bear.append("A点跌破↓")
    
    # 趋势线突破（回测偏弱，权�?�?
    tl_bull = tl_bear = False
    if tl and tl.get("broken"):
        if tl.get("type") == "downtrend":
            tl_bull = True; tool_bull += 1; tool_notes_bull.append("趋势线突破↑")
        elif tl.get("type") == "uptrend":
            tl_bear = True; tool_bear += 1; tool_notes_bear.append("趋势线跌破↓")
    
    # 规则十四：趋势线+A点同向突�?= 系统最强信�?
    strongest_bull = tl_bull and a_bull
    strongest_bear = tl_bear and a_bear
    if strongest_bull:
        tool_bull += 1; tool_notes_bull.append("★趋势线+A点同�?)
    if strongest_bear:
        tool_bear += 1; tool_notes_bear.append("★趋势线+A点同�?)
    
    # ── K线形态“关键位置”过滤（�?版第四章：非关键位置的K�?噪音）──
    # 关键位置 = 价值区边缘(支撑/阻力) �?价格贴近系统工具�?趋势�?拐点�?分界点A)
    key_tol = (atr or 10) * 1.5
    _key_levels = []
    if tl and tl.get("current_value") is not None:
        _key_levels.append(tl["current_value"])
    if ch and ch.get("current_value") is not None:
        _key_levels.append(ch["current_value"])
    if pa and pa.get("main_a"):
        _key_levels.append(pa["main_a"]["price"])
    near_key_level = any(abs(current - lv) <= key_tol for lv in _key_levels)
    bull_pattern_valid = has_bull_pattern and (at_support or near_key_level)
    bear_pattern_valid = has_bear_pattern and (at_resistance or near_key_level)

    # ── 综合评分（满�?0）──
    long_score = 0
    short_score = 0
    
    long_score += 2 if at_support else 0
    long_score += 1 if rsi_oversold_recovering else 0
    long_score += 2 if bull_pattern_valid else 0
    long_score += tool_bull
    
    short_score += 2 if at_resistance else 0
    short_score += 1 if rsi_overbought_cooling else 0
    short_score += 2 if bear_pattern_valid else 0
    short_score += tool_bear
    
    long_score = min(long_score, SIGNAL_MAX_SCORE)
    short_score = min(short_score, SIGNAL_MAX_SCORE)
    
    # ── 生成信号（含 4H 方向过滤）──
    long_trigger = long_score >= 5
    short_trigger = short_score >= 5
    
    # 规则十四最强信号可无视基础分门�?
    if strongest_bull:
        long_trigger = True
    if strongest_bear:
        short_trigger = True
    
    # 4H 方向过滤：只做顺势，砍掉逆势抄底/摸顶
    filtered_long = filtered_short = False
    if trend_4h == "down" and long_trigger:
        long_trigger = False; filtered_long = True
    if trend_4h == "up" and short_trigger:
        short_trigger = False; filtered_short = True
    
    return {
        "long_score": long_score,
        "short_score": short_score,
        "max_score": SIGNAL_MAX_SCORE,
        "long_trigger": long_trigger,
        "short_trigger": short_trigger,
        "at_support": at_support,
        "at_resistance": at_resistance,
        "rsi_oversold_recovering": rsi_oversold_recovering,
        "rsi_overbought_cooling": rsi_overbought_cooling,
        "patterns": patterns,
        "bull_patterns": [p["desc"] for p in bull_patterns],
        "bear_patterns": [p["desc"] for p in bear_patterns],
        "tool_notes_bull": tool_notes_bull,
        "tool_notes_bear": tool_notes_bear,
        "strongest_bull": strongest_bull,
        "strongest_bear": strongest_bear,
        "trend_4h": trend_4h,
        "filtered_long": filtered_long,
        "filtered_short": filtered_short,
    }


# ─── 合约辅助数据 ───────────────────────────────────

def analyze_contract_stats(stats):
    """解析合约统计（ccxt + 原始API 混合格式�?""
    if not stats:
        return None
    
    signals = []
    
    # 持仓�?
    oi_usd = float(stats.get("open_interest_usd", 0) or 0)
    
    # 资金费率 (ccxt 格式: {"fundingRate": ..., ...})
    funding = stats.get("funding_rate")
    funding_rate = None
    if funding and isinstance(funding, dict):
        funding_rate = float(funding.get("fundingRate", 0) or 0) * 100
        if funding_rate > 0.1:
            signals.append(f"资金费率极高({funding_rate:.2f}%) �?多头拥挤")
        elif funding_rate < -0.05:
            signals.append(f"资金费率极负({funding_rate:.2f}%) �?空头拥挤")
        else:
            signals.append(f"资金费率正常({funding_rate:.3f}%)")
    elif funding and isinstance(funding, (int, float)):
        funding_rate = float(funding)
    
    # 主动买卖�?
    lsr_taker = float(stats.get("lsr_taker", 1) or 1)
    if lsr_taker > 1.2:
        signals.append("主动买盘强势")
    elif lsr_taker < 0.8:
        signals.append("主动卖盘强势")
    else:
        signals.append("主动买卖均衡")
    
    # 大户多空�?
    lsr_account = float(stats.get("lsr_account", 1) or 1)
    if lsr_account > 1.5:
        signals.append("大户偏多")
    elif lsr_account < 0.67:
        signals.append("大户偏空")
    else:
        signals.append("大户中�?)
    
    # 多空人数�?
    long_rate = float(stats.get("long_rate", 0) or 0)
    short_rate = float(stats.get("short_rate", 0) or 0)
    if long_rate > 0 and short_rate > 0:
        retail_ratio = long_rate / short_rate if short_rate > 0 else 1
        if retail_ratio > 2:
            signals.append("散户极端看多 �?警惕反转")
        elif retail_ratio < 0.5:
            signals.append("散户极端看空 �?警惕反转")
    
    result = {
        "lsr_taker": round(lsr_taker, 3),
        "lsr_account": round(lsr_account, 3),
        "oi_usd": round(oi_usd, 0),
    }
    if funding_rate is not None:
        result["funding_rate"] = round(funding_rate, 4)
    if signals:
        result["signals"] = signals
    
    return result


# ─── 主分析流�?─────────────────────────────────────

def analyze(symbol="XAUUSD", timeframe="1h"):
    """完整分析，返回结构化结果"""
    candles, preclose, stats = fetch_data(symbol, timeframe)
    closes = [c["close"] for c in candles]
    
    result = {
        "symbol": symbol.upper(),
        "timeframe": timeframe,
        "candle_count": len(candles),
        "current_price": closes[-1],
        "preclose": preclose,
    }
    
    # RSI
    rsi9 = calc_rsi(closes, 9)
    rsi14 = calc_rsi(closes, 14)
    result["rsi9"] = round(rsi9[-1], 1) if rsi9 else None
    result["rsi14"] = round(rsi14[-1], 1) if rsi14 else None
    result["rsi9_oversold"] = rsi9 and any(r < 30 for r in rsi9[-20:])
    result["rsi9_overbought"] = rsi9 and any(r > 70 for r in rsi9[-20:])

    # ATR
    atr_vals = calc_atr(candles, 14)
    result["atr14"] = round(atr_vals[-1], 2) if atr_vals else None
    
    # 拐点
    swings = find_swings(candles)
    result["swing_count"] = len(swings)

    # RSI 背离
    result["rsi_divergence"] = detect_rsi_divergence(candles, swings, rsi9)
    
    # 波浪
    waves, trend = count_waves(swings, len(candles))
    result["trend"] = trend
    result["waves"] = waves
    
    # Qjt 区间跨度（趋势线需�?Qjt 判定�?导航，先算）
    qjt_result = calc_qjt(candles)
    result["qjt"] = qjt_result
    
    # 趋势线（传入 Qjt 用于�?导航判断�?
    trendline = find_trendline(candles, swings, qjt_result)
    result["trendline"] = trendline
    
    # 拐点线（传入 Qjt 用于趋势/导航判断�?
    channel = find_channel(candles, swings, qjt_result)
    result["channel"] = channel
    
    # 分界点A（传�?Qjt 和趋势方向）
    pivot_a = find_pivot_a(candles, swings, qjt_result, trend)
    result["pivot_a"] = pivot_a
    
    # 波浪结构分类
    result["trend_structure"] = classify_trend_structure(qjt_result)

    # 数浪法则4~8
    result["wave_rules"] = apply_wave_rules(candles, qjt_result)

    # 斐波那契回调�?
    result["retracements"] = calc_retracements(candles, qjt_result)

    # Tp/Ta 判定
    result["tp_ta"] = calc_tp_ta(candles, qjt_result, swings)

    # 斐波那契周期
    result["fib_cycle"] = fib_cycle_track(qjt_result)
    
    # PSTD 目标�?
    result["pstd_targets"] = calc_pstd_targets(candles, qjt_result, trend)
    
    # 缓冲�?
    result["buffer"] = buffer_analysis(candles)
    
    # 合约数据
    if stats:
        result["contract"] = analyze_contract_stats(stats)
    
    # 信号评估
    result["signal"] = evaluate_signal(result, candles)
    result["_candles"] = candles
    
    return result


# ─── 格式化输�?─────────────────────────────────────

def format_analysis(r):
    """将分析结果格式化为可读文�?""
    lines = []
    
    title = f"══�?{r['symbol']} 1H 趋势交易法分�?══�?
    lines.append(title)
    lines.append("")
    
    # 基本行情
    lines.append("【行情速览�?)
    lines.append(f"  当前�? {r['current_price']:.2f}")
    if r.get("preclose"):
        gap = r['current_price'] - float(r['preclose'])
        lines.append(f"  前收�? {r['preclose']}  (跳空 {gap:+.1f})")
    lines.append(f"  K线数: {r['candle_count']}")
    lines.append("")
    
    # RSI
    lines.append("【RSI 指标�?)
    rsi9_str = f"{r['rsi9']:.1f}" if r['rsi9'] else "N/A"
    rsi14_str = f"{r['rsi14']:.1f}" if r['rsi14'] else "N/A"
    rsi_extra = []
    if r.get("rsi9_oversold"):
        rsi_extra.append("近期进入过超�?<30)")
    if r.get("rsi9_overbought"):
        rsi_extra.append("近期进入过超�?>70)")
    extra_str = "�?.join(rsi_extra) if rsi_extra else ""
    lines.append(f"  RSI(9)={rsi9_str}  RSI(14)={rsi14_str}  ATR(14)={r.get('atr14','N/A')}")
    if extra_str:
        lines.append(f"  {extra_str}")
    lines.append("")
    
    # 趋势
    trend_cn = {"up": "�?上升", "down": "�?下降", "unknown": "�?不确�?, "sideways": "�?横向整理"}
    lines.append("【趋势方向�?)
    lines.append(f"  主趋�? {trend_cn.get(r['trend'], r['trend'])}")
    lines.append("")
    
    # 趋势�?
    if r["trendline"]:
        tl = r["trendline"]
        tl_type = "下降趋势�? if tl["type"] == "downtrend" else "上升趋势�?
        status = "�?已突�?" if tl["broken"] else "�?未突�?
        level = tl.get("tl_level", "")
        level_str = f"  [{level}]" if level else ""
        lines.append("【趋势线�?)
        lines.append(f"  类型: {tl_type}{level_str}")
        if tl.get("tl_delta") is not None:
            lines.append(f"  δ={tl['tl_delta']} (当前趋势maxQjt={tl['tl_cur_max_qjt']} / 前反向lastQjt={tl['tl_prev_last_qjt']})")
        lines.append(f"  连接: {tl['p1']['price']:.2f} �?{tl['p2']['price']:.2f}")
        lines.append(f"  当前�? {tl['current_value']:.2f}  ({status})")
        if tl["broken"] and tl.get("turn_type"):
            lines.append(f"  转向方式: {tl['turn_type']} �?{tl['turn_reason']}")
        lines.append("")
    
    # 拐点�?
    if r.get("channel"):
        ch = r["channel"]
        ch_type = "上升拐点�? if ch["type"] == "uptrend" else "下降拐点�?
        level = ch.get("channel_level", "")
        level_str = f"  [{level}]" if level else ""
        status = "�?已突�?" if ch["broken"] else "�?未突�?
        lines.append("【拐点线�?)
        lines.append(f"  类型: {ch_type}{level_str}")
        if ch.get("channel_delta") is not None:
            lines.append(f"  δ={ch['channel_delta']}")
        lines.append(f"  外延�? {ch['outer_p1']['price']:.2f} �?{ch['outer_p2']['price']:.2f}")
        lines.append(f"  拐点�? {ch['channel_pivot']['price']:.2f} (�?{'�? if ch['type']=='uptrend' else '�?}�?")
        lines.append(f"  拐点线当�? {ch['current_value']:.2f}  ({status})")
        if ch["broken"] and ch.get("turn_type"):
            lines.append(f"  转向方式: {ch['turn_type']} �?{ch['turn_reason']}")
        lines.append("")
    
    # 分界点A
    pa = r.get("pivot_a")
    if pa and (pa.get("main_a") or pa.get("nav_a")):
        main_a = pa.get("main_a")
        nav_a = pa.get("nav_a")
        lines.append("【分界点A�?)
        if main_a:
            a_type = "高点" if main_a["type"] == "high" else "低点"
            # 趋势结构完整：上升A=低点需价格在上，下降A=高点需价格在下
            intact = (main_a["type"] == "low" and r["current_price"] > main_a["price"]) or \
                     (main_a["type"] == "high" and r["current_price"] < main_a["price"])
            near = abs(r["current_price"] - main_a["price"]) <= (r.get("atr14", 1) or 1)
            if near:
                a_status = "�?正在争夺（距A不到1 ATR�?
            elif intact:
                a_status = "�?结构完整"
            else:
                a_status = "�?结构破坏!"
            lines.append(f"  主趋势A: {main_a['price']:.2f} ({a_type})  [{main_a.get('a_kind','')}]  {a_status}")
            if main_a.get("qjt_from"):
                lines.append(f"    区间: Qjt={main_a['qjt_from']}→{main_a['qjt_to']}")
        if nav_a:
            lines.append(f"  导航A: {nav_a['price']:.2f}  [{nav_a.get('a_kind','')}]")
        lines.append("")
    
    # 波浪
    if r["waves"] and len(r["waves"]) >= 3:
        lines.append("【波浪结构�?)
        for i, w in enumerate(r["waves"]):
            wtype = "�? if w["type"] == "high" else "�?
            lines.append(f"  点{i+1}: {w['price']:.2f} ({wtype})  idx={w['idx']}")
        lines.append("")
    
    # 缓冲�?
    buf = r["buffer"]
    lines.append("【缓冲带�?)
    lines.append(f"  区间: {buf['range_low']:.2f} - {buf['range_high']:.2f}  ({buf['total_range']:.1f}pt)")
    lines.append(f"  当前位置: {buf['position_pct']:.0f}%  (价值区: {buf['value_area']})")
    lines.append(f"  放量方向: {buf['big_volume_bias']}")
    lines.append("")
    lines.append("  支撑:")
    for s in buf["supports"]:
        dist = buf["current"] - s["level"]
        lines.append(f"    {s['level']:.2f}  ({dist:+.1f}pt)  {s['label']}")
    lines.append("  阻力:")
    for rl in buf["resistances"]:
        dist = rl["level"] - buf["current"]
        lines.append(f"    {rl['level']:.2f}  ({dist:+.1f}pt)  {rl['label']}")
    lines.append("")
    
    # 合约数据
    if r.get("contract"):
        ct = r["contract"]
        lines.append("【合约辅助�?)
        lines.append(f"  主动买卖�? {ct['lsr_taker']}  大户多空�? {ct['lsr_account']}")
        if ct.get("funding_rate") is not None:
            lines.append(f"  资金费率: {ct['funding_rate']}%")
        if ct.get("oi_usd"):
            lines.append(f"  持仓量OI: ${ct['oi_usd']:,.0f}")
        for sig in ct.get("signals", []):
            lines.append(f"  �?{sig}")
        lines.append("")
    
    # 综合判断
    lines.append("【综合判断�?)
    
    # 判断逻辑
    signals_bull = 0
    signals_bear = 0
    
    # 趋势线突�?
    if r["trendline"] and r["trendline"]["broken"]:
        if r["trendline"]["type"] == "downtrend":
            signals_bull += 2
        else:
            signals_bear += 2
    
    # 分界点A
    pa = r.get("pivot_a")
    if pa:
        main_a = pa.get("main_a")
        if main_a:
            above = (main_a["type"] == "low" and r["current_price"] > main_a["price"]) or \
                    (main_a["type"] == "high" and r["current_price"] < main_a["price"])
            near = abs(r["current_price"] - main_a["price"]) <= (r.get("atr14", 1) or 1)
            if above and main_a["type"] == "high":
                signals_bull += 2
            elif not above and not near and main_a["type"] == "low":
                signals_bear += 2
    
    # RSI
    if r.get("rsi9_oversold"):
        signals_bull += 1
    if r.get("rsi9_overbought"):
        signals_bear += 1
    
    # 当前RSI
    if r["rsi9"] is not None:
        if r["rsi9"] < 30:
            signals_bull += 1
        elif r["rsi9"] > 70:
            signals_bear += 1
    
    if signals_bull > signals_bear + 1:
        lines.append("  方向: �?偏多")
    elif signals_bear > signals_bull + 1:
        lines.append("  方向: �?偏空")
    else:
        lines.append("  方向: �?震荡 / 等待方向")
    
    lines.append(f"  多空信号比分: 多头{signals_bull} : 空头{signals_bear}")
    
    return "\n".join(lines)


# ─── 双周期分�?─────────────────────────────────────

def analyze_dual(symbol):
    """双周期分�? 1H + 4H"""
    r1h = analyze(symbol, "1h")
    r4h = analyze(symbol, "4h")
    
    # 双周期方向判�?
    t1h = r1h["trend"]
    t4h = r4h["trend"]
    
    # �?4H 方向重算 1H 信号（启用顺势过滤）
    r1h["signal"] = evaluate_signal(r1h, r1h["_candles"], trend_4h=t4h)
    
    direction_map = {
        ("up", "up"): ("▲▲ 强烈看多", "4H+1H 同向上升，顺势做�?),
        ("up", "down"): ("�?谨慎看多", "4H上升�?H回调�?�?�?H止跌做多"),
        ("up", "sideways"): ("�?偏多", "4H上升�?H盘整 �?�?H向上突破"),
        ("down", "down"): ("▼▼ 强烈看空", "4H+1H 同向下降，顺势做�?),
        ("down", "up"): ("�?谨慎看空", "4H下降�?H反弹�?�?�?H遇阻做空"),
        ("down", "sideways"): ("�?偏空", "4H下降�?H盘整 �?�?H向下跌破"),
        ("sideways", "up"): ("�?震荡偏多", "4H横向整理�?H上升 �?按横向整理做�?),
        ("sideways", "down"): ("�?震荡偏空", "4H横向整理�?H下降 �?按横向整理做�?),
        ("sideways", "sideways"): ("�?横向整理", "4H+1H 双周期横�?�?按区间操�?),
    }
    
    key = (t4h if t4h else "unknown", t1h if t1h else "unknown")
    direction, suggestion = direction_map.get(key, ("? 无法判定", "数据不足"))
    
    return {
        "symbol": symbol.upper(),
        "r1h": r1h,
        "r4h": r4h,
        "dual_direction": direction,
        "dual_suggestion": suggestion,
    }


def format_dual(d):
    """格式化双周期分析输出"""
    lines = []
    r1h = d["r1h"]
    r4h = d["r4h"]
    
    title = f"══�?{d['symbol']} 双周�?(1H + 4H) 趋势交易法分�?══�?
    lines.append(title)
    lines.append("")
    
    # ── 双周期结论（最重要，放在最前面）──
    lines.append("【双周期综合结论�?)
    lines.append(f"  方向: {d['dual_direction']}")
    lines.append(f"  策略: {d['dual_suggestion']}")
    lines.append("")
    
    # ── 4H 大周�?──
    lines.append("── 4H 大周期（方向过滤�?──")
    trend_cn = {"up": "�?上升", "down": "�?下降", "sideways": "�?横向整理", "unknown": "�?不确�?}
    lines.append(f"  趋势: {trend_cn.get(r4h['trend'], r4h['trend'])}")
    if r4h.get("rsi9") is not None:
        lines.append(f"  RSI(9)={r4h['rsi9']:.1f}  ATR(14)={r4h.get('atr14','N/A')}")
    if r4h["trendline"]:
        tl = r4h["trendline"]
        tl_type = "下降趋势�? if tl["type"] == "downtrend" else "上升趋势�?
        status = "�?已突�?" if tl["broken"] else "未突�?
        level = tl.get("tl_level", "")
        level_str = f" [{level}]" if level else ""
        lines.append(f"  趋势�?{tl_type}{level_str}): {tl['p1']['price']:.2f}→{tl['p2']['price']:.2f} 当前:{tl['current_value']:.2f} {status}")
    if r4h["pivot_a"]:
        pa = r4h["pivot_a"]
        main_a = pa.get("main_a")
        if main_a:
            lines.append(f"  分界点A: {main_a['price']:.2f} [{main_a.get('a_kind','')}]")
    if r4h.get("channel"):
        ch = r4h["channel"]
        ch_type = "上升拐点�? if ch["type"] == "uptrend" else "下降拐点�?
        level = ch.get("channel_level", "")
        level_str = f" [{level}]" if level else ""
        status = "�?已突�?" if ch["broken"] else "未突�?
        lines.append(f"  拐点�?{ch_type}{level_str}): 外延{ch['outer_p1']['price']:.2f}→{ch['outer_p2']['price']:.2f}  拐点�?{ch['channel_pivot']['price']:.2f}  当前:{ch['current_value']:.2f} {status}")
    lines.append(f"  区间: {r4h['buffer']['range_low']:.2f} - {r4h['buffer']['range_high']:.2f}")
    
    ts = r4h.get("trend_structure", {})
    for key, label in [("uptrend", "上升"), ("downtrend", "下降")]:
        st = ts.get(key)
        if st and st.get("reversal_pct"):
            lines.append(f"  {label}结构: {st['structure']} (反转{st['reversal_pct']}%)")
    lines.append("")
    
    # ── 1H 小周期（入场）──
    lines.append("── 1H 执行周期（入场找点） ──")
    lines.append(f"  当前�? {r1h['current_price']:.2f}")
    if r1h.get("preclose"):
        lines.append(f"  前收�? {r1h['preclose']}")
    lines.append(f"  趋势: {trend_cn.get(r1h['trend'], r1h['trend'])}")
    if r1h.get("rsi9") is not None:
        rsi_extra = []
        if r1h.get("rsi9_oversold"): rsi_extra.append("近期超卖")
        if r1h.get("rsi9_overbought"): rsi_extra.append("近期超买")
        extra = " (" + ",".join(rsi_extra) + ")" if rsi_extra else ""
        lines.append(f"  RSI(9)={r1h['rsi9']:.1f}  ATR(14)={r1h.get('atr14','N/A')}{extra}")
    if r1h["trendline"]:
        tl = r1h["trendline"]
        status = "�?已突�?" if tl["broken"] else "未突�?
        level = tl.get("tl_level", "")
        level_str = f" [{level}]" if level else ""
        tl_info = f"  趋势线{level_str}: {status}"
        if tl["broken"] and tl.get("turn_type"):
            tl_info += f" �?{tl['turn_type']}"
        lines.append(tl_info)
    # RSI 背离
    rsi_div = r1h.get("rsi_divergence")
    if rsi_div:
        for d in rsi_div:
            lines.append(f"  RSI{d['desc']}: {d['detail']}")
    if r1h["pivot_a"]:
        pa = r1h["pivot_a"]
        main_a = pa.get("main_a")
        if main_a:
            intact = (main_a["type"] == "low" and r1h["current_price"] > main_a["price"]) or \
                     (main_a["type"] == "high" and r1h["current_price"] < main_a["price"])
            lines.append(f"  分界点A: {main_a['price']:.2f} ({'结构完整' if intact else '结构破坏!'}) [{main_a.get('a_kind','')}]")
    if r1h.get("channel"):
        ch = r1h["channel"]
        status = "�?已突�?" if ch["broken"] else "未突�?
        level = ch.get("channel_level", "")
        level_str = f" [{level}]" if level else ""
        ch_info = f"  拐点线{level_str}: {status}"
        if ch["broken"] and ch.get("turn_type"):
            ch_info += f" �?{ch['turn_type']}"
        lines.append(ch_info)
    
    # 波浪结构
    ts = r1h.get("trend_structure", {})
    if ts:
        for key, label in [("uptrend", "上升"), ("downtrend", "下降")]:
            st = ts.get(key)
            if st:
                rev = f" 反转{st['reversal_pct']}%" if st.get("reversal_pct") else ""
                lines.append(f"  {label}结构: {st['structure']}{rev}")
    
    # PSTD 目标�?
    pt = r1h.get("pstd_targets", {})
    if pt and pt.get("wave1_height"):
        tgt_str = " / ".join(f"{t:.2f}" for t in pt["targets"][:3])
        lines.append(f"  PSTD目标(�?高{pt['wave1_height']:.1f}): {tgt_str}")

    # ── 斐波那契回调入场�?──
    rets = r1h.get("retracements")
    if rets:
        # 只显示最近的主浪回调位（与当前趋势方向一致）
        current_trend = r1h.get("trend")
        relevant = [r for r in rets if r["dir"] == current_trend]
        if relevant:
            # 取最近一�?
            latest = relevant[-1]
            ret = latest["retrace"]
            lines.append(f"  回调入场(浪{latest['num']} 幅度{latest['range']:.1f}):")
            lines.append(f"    40%={ret.get('40%', 'N/A')}  62%={ret.get('62%', 'N/A')}  78.6%={ret.get('78.6%', 'N/A')}")
    
    buf = r1h["buffer"]
    lines.append(f"  价值区: {buf['value_area']}")
    lines.append(f"  放量方向: {buf['big_volume_bias']}")
    
    # ── Qjt 区间跨度 ──
    qjt = r1h.get("qjt")
    if qjt:
        hi_info = qjt.get("high", {})
        lo_info = qjt.get("low", {})
        hi = hi_info.get("count", 0)
        li = lo_info.get("count", 0)
        if hi > 0 or li > 0:
            lines.append(f"  Qjt: 已突破高点{hi}�? 低点{li}�?)

        # 最近区间对的关�?
        hp = hi_info.get("latest_pair")
        lp = lo_info.get("latest_pair")
        if hp:
            lines.append(f"  最近高点对: Qjt={hp['from']['qjt']}→{hp['to']['qjt']} ({hp['rel']})")
        if lp:
            lines.append(f"  最近低点对: Qjt={lp['from']['qjt']}→{lp['to']['qjt']} ({lp['rel']})")

        # 趋势预测
        max_hi = hi_info.get("max", 0)
        max_lo = lo_info.get("max", 0)
        if max_hi > MAX_QJT_THRESHOLD and hi >= 2:
            lines.append(f"  上升趋势结构: 最大Qjt={max_hi}，可画趋势线")
        if max_lo > 39 and li >= 2:
            lines.append(f"  下降趋势结构: 最大Qjt={max_lo}，可画趋势线")

    # 斐波那契周期
    fib = r1h.get("fib_cycle")
    if fib:
        fib_notes = [f["note"] for f in fib[-6:]]
        if fib_notes:
            lines.append(f"  斐波周期: {' | '.join(fib_notes)}")

    # ── 数浪法则 4~8 ──
    wr = r1h.get("wave_rules")
    if wr and wr.get("summary"):
        has_trigger = any(not s.startswith("�?) for s in wr["summary"])
        if has_trigger:
            # 只显示升�?降级/合并关键项，过滤法则4噪音
            key_rules = [s for s in wr["summary"] if "升级" in s or "降级" in s or "法则5" in s or "法则6" in s]
            if key_rules:
                lines.append("")
                lines.append("  【数浪法则诊断�?)
                for s in key_rules:
                    lines.append(f"    {s}")
            else:
                # 只有法则4触发，给出简洁提�?
                lines.append("")
                lines.append("  【数浪法则�?法则4(先内后外)触发，优先处理内区间结构")

    # ── Tp/Ta 判定 ──
    tpta = r1h.get("tp_ta")
    if tpta:
        adj_flags = [x for x in tpta if x.get("is_adjustment_likely")]
        if adj_flags:
            lines.append("")
            lines.append("  【Tp/Ta判定�?)
            for a in adj_flags[-3:]:  # 最�?�?
                lines.append(f"    Tp={a['tp']}/Ta={a['ta']}={a['ratio']:.2f} �?{a['desc']}")
    
    # ── 量化信号 ──
    sig = r1h.get("signal")
    if sig:
        mx = sig.get("max_score", 10)
        lines.append("")
        lines.append("  【量化信号评分�?)
        lines.append(f"    做多: {sig['long_score']}/{mx}  |  做空: {sig['short_score']}/{mx}")
        
        conditions = []
        if sig["at_support"]:
            conditions.append("�?价格在支撑区")
        else:
            conditions.append("�?价格不在支撑�?)
        if sig["rsi_oversold_recovering"]:
            conditions.append("�?RSI超卖恢复�?)
        else:
            conditions.append("�?RSI不在超卖恢复�?)
        if sig["bull_patterns"]:
            conditions.append(f"�?K�? {', '.join(sig['bull_patterns'])}")
        else:
            conditions.append("�?无看涨反转形�?)
        if sig.get("tool_notes_bull"):
            conditions.append("�?" + "+".join(sig["tool_notes_bull"]))
        
        conditions2 = []
        if sig["at_resistance"]:
            conditions2.append("�?价格在阻力区")
        else:
            conditions2.append("�?价格不在阻力�?)
        if sig["rsi_overbought_cooling"]:
            conditions2.append("�?RSI超买回落�?)
        else:
            conditions2.append("�?RSI不在超买回落�?)
        if sig["bear_patterns"]:
            conditions2.append(f"�?K�? {', '.join(sig['bear_patterns'])}")
        else:
            conditions2.append("�?无看跌反转形�?)
        if sig.get("tool_notes_bear"):
            conditions2.append("�?" + "+".join(sig["tool_notes_bear"]))
        
        lines.append(f"    做多条件: {' | '.join(conditions)}")
        lines.append(f"    做空条件: {' | '.join(conditions2)}")
        
        if sig["long_trigger"]:
            tag = " ★最强信�? if sig.get("strongest_bull") else ""
            lines.append(f"    �?做多信号触发！{tag}")
        if sig["short_trigger"]:
            tag = " ★最强信�? if sig.get("strongest_bear") else ""
            lines.append(f"    �?做空信号触发！{tag}")
        if sig.get("filtered_long"):
            lines.append("    �?做多分数达标但被 4H 下降趋势过滤（不逆势抄底�?)
        if sig.get("filtered_short"):
            lines.append("    �?做空分数达标但被 4H 上升趋势过滤（不逆势摸顶�?)
        if not sig["long_trigger"] and not sig["short_trigger"] \
                and not sig.get("filtered_long") and not sig.get("filtered_short"):
            lines.append("    �?无信号，等待条件成熟")
    
    lines.append("")
    
    # ── 支撑阻力 ──
    lines.append("── 关键价位 ──")
    lines.append(f"  支撑: " + " | ".join(f"{s['level']:.2f}" for s in buf["supports"]))
    lines.append(f"  阻力: " + " | ".join(f"{r['level']:.2f}" for r in buf["resistances"]))
    lines.append("")
    
    # ── 入场建议 ──
    lines.append("── 入场建议 ──")
    
    t4 = r4h["trend"]
    t1 = r1h["trend"]
    buf = r1h["buffer"]
    current = r1h["current_price"]
    atr = r1h.get("atr14", 10) or 10
    
    # 价值区边界
    va_parts = buf["value_area"].split(" - ")
    va_low = float(va_parts[0]) if len(va_parts) == 2 else current - atr
    va_high = float(va_parts[1]) if len(va_parts) == 2 else current + atr
    
    # 找最近阻力（�?current 上方且在 3 ATR 以内的）
    near_res = [r for r in buf["resistances"] if r["level"] > current and r["level"] - current <= atr * 5]
    near_sup = [s for s in buf["supports"] if s["level"] < current and current - s["level"] <= atr * 5]
    
    if t4 == "up" and t1 == "up":
        lines.append("  顺势做多 | �?H回调至支撑区入场")
        if near_sup:
            entry = near_sup[-1]["level"]  # 最近支�?
            stop = entry - atr * 1.5
        else:
            entry = va_low
            stop = current - atr * 2
        lines.append(f"  入场�? {entry:.2f} | 止损: {stop:.2f} | 目标: {va_high:.2f}")
    elif t4 == "down" and t1 == "down":
        if near_res:
            lines.append("  顺势做空 | �?H反弹至近端阻力入�?)
            entry = near_res[0]["level"]
            stop = entry + atr * 1.5
            lines.append(f"  入场�? {entry:.2f} | 止损: {stop:.2f} | 目标: {va_low:.2f}")
        else:
            near_s = near_sup[-1]["level"] if near_sup else current - atr
            lines.append("  顺势做空 | 价格已在低位，两种应对：")
            lines.append(f"  �?等反弹至 {va_high:.2f} 附近遇阻做空")
            lines.append(f"  �?若跌�?{near_s:.2f} 追空 | 止损: {near_s + atr * 2:.2f}")
    elif t4 == "up" and t1 in ("down", "sideways"):
        lines.append("  等待1H止跌 | 4H向上�?H回调是上车机�?)
        entry = near_sup[-1]["level"] if near_sup else va_low
        lines.append(f"  关注: {entry:.2f} 附近出现阳线反转 �?入场做多")
    elif t4 == "down" and t1 in ("up", "sideways"):
        lines.append("  等待1H遇阻 | 4H向下�?H反弹是放空机�?)
        entry = near_res[0]["level"] if near_res else va_high
        lines.append(f"  关注: {entry:.2f} 附近出现阴线反转 �?入场做空")
    elif t4 == "sideways":
        lines.append("  4H横向整理 | 按区间高抛低�?)
        lines.append(f"  做多�? {va_low:.2f} | 做空�? {va_high:.2f}")
    else:
        lines.append("  信号不明确，建议观望")
    
    return "\n".join(lines)


# ─── 入口 ────────────────────────────────────────────

if __name__ == "__main__":
    symbol = sys.argv[1] if len(sys.argv) > 1 else "XAUUSD"

    # 仓位计算器模�?
    if symbol.lower() == "calc":
        if len(sys.argv) < 4:
            print("用法: python trend_analyzer.py calc <总资�?USDT)> <止损点数> [杠杆倍数]")
            print("�? python trend_analyzer.py calc 20000 500 10")
            print("    �?总资�?万USDT, 止损500�? 10倍杠�?)
            sys.exit(0)
        capital = float(sys.argv[2])
        stop_pts = float(sys.argv[3])
        lev = int(sys.argv[4]) if len(sys.argv) > 4 else 1
        r = calc_position(capital, stop_pts, leverage=lev)
        print(f"══�?仓位计算 ══�?)
        print(f"  总资�? ${r['total_capital']:,.0f}")
        print(f"  总风险金(30%): ${r['risk_capital']:,.2f}")
        print(f"  每笔最大亏�?10分法): ${r['per_trade_risk']:,.2f}")
        print(f"  止损点数: {r['stop_points']}")
        print(f"  最大仓�? {r['position_size']:.4f} �?)
        if r.get("margin_required"):
            print(f"  所需保证�? ${r['margin_required']:,.2f}")
        if r.get("risk_warning"):
            print(f"  �?{r['risk_warning']}")
        sys.exit(0)
    
    def _print_trade_status():
        """在行情分析后附加交易状�?""
        import json
        log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".factory", "trades.json")
        if not os.path.exists(log_path):
            return
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except:
            return

        trades = data.get("trades", [])
        if not trades:
            return

        open_positions = [t for t in trades if t.get("exit_price") is None]
        closed = [t for t in trades if t.get("exit_price") is not None]

        print(f"\n── 交易状�?──")
        if open_positions:
            for t in open_positions:
                print(f"  持仓 #{t['id']}: {t['symbol']} {t['direction']} @{t['entry']} "
                      f"止损{t['stop_loss']} 仓位{t['size']}�?)
        else:
            print(f"  无持�?)

        if closed:
            recent = closed[-5:]
            total_pnl = sum(t.get("pnl", 0) or 0 for t in closed)
            wins = sum(1 for t in closed if t.get("pnl") and t["pnl"] > 0)
            print(f"  累计: {len(closed)}�?| 胜率 {wins/len(closed)*100:.0f}% | "
                  f"PnL ${total_pnl:,.0f}")

            # 连盈/连亏
            streak = 0
            streak_type = None
            for t in reversed(closed):
                if t.get("pnl") is None:
                    break
                is_win = t["pnl"] > 0
                if streak_type is None:
                    streak_type = "�? if is_win else "�?
                if is_win == (streak_type == "�?):
                    streak += 1
                else:
                    break
            if streak > 1:
                color = "🟢" if streak_type == "�? else "🔴"
                print(f"  当前: {color} 连{streak_type}{streak}�?)


    print(f"正在拉取 {symbol} 1H + 4H 数据...")
    try:
        result = analyze_dual(symbol)
        print(format_dual(result))
        _print_trade_status()
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
