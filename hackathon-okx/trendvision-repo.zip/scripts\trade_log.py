"""
交易日志模块 �?记录、统计、复�?
用法:
  python trade_log.py record BTC long 62710 62200 0.5 "趋势�?分界点A同时触发"
  python trade_log.py close 1 63500
  python trade_log.py stats
  python trade_log.py review
  python trade_log.py list
"""

import json
import os
import sys
from datetime import datetime, timezone, timedelta

TZ = timezone(timedelta(hours=8))
LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".factory", "trades.json")


def _load():
    if not os.path.exists(LOG_PATH):
        return {"trades": [], "reviews": []}
    with open(LOG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(data):
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def record_trade(symbol, direction, entry, stop_loss, size, reason, leverage=10):
    """记录一笔新交易"""
    data = _load()
    trade = {
        "id": len(data["trades"]) + 1,
        "symbol": symbol.upper(),
        "direction": direction.lower(),
        "entry": float(entry),
        "stop_loss": float(stop_loss),
        "size": float(size),
        "leverage": int(leverage),
        "reason": reason,
        "open_time": datetime.now(TZ).strftime("%Y-%m-%d %H:%M"),
        "open_ts": datetime.now(TZ).timestamp(),
        "exit_price": None,
        "exit_time": None,
        "exit_reason": None,
        "pnl": None,
        "pnl_pct": None,
        "system_compliant": None,  # 待平仓时评估
    }
    data["trades"].append(trade)
    _save(data)
    entry_f = float(entry)
    stop_f = float(stop_loss)
    size_f = float(size)
    print(f"交易 #{trade['id']} 已记�? {symbol} {direction} @{entry} 止损{stop_loss} 仓位{size}�?)
    print(f"  依据: {reason}")
    print(f"  最大亏�? ${abs(entry_f - stop_f) * size_f * leverage:.0f}")
    return trade


def close_trade(trade_id, exit_price, exit_reason="", system_compliant=None):
    """平仓一笔交�?""
    data = _load()
    trade = next((t for t in data["trades"] if t["id"] == int(trade_id)), None)
    if not trade:
        print(f"错误: 找不到交�?#{trade_id}")
        return None

    trade["exit_price"] = float(exit_price)
    trade["exit_time"] = datetime.now(TZ).strftime("%Y-%m-%d %H:%M")
    trade["exit_reason"] = exit_reason or "手动平仓"

    entry = trade["entry"]
    direction = trade["direction"]
    size = trade["size"]
    leverage = trade.get("leverage", 10)

    if direction == "long":
        pnl = (float(exit_price) - entry) * size * leverage
        pnl_pct = (float(exit_price) - entry) / entry * 100 * leverage
    else:
        pnl = (entry - float(exit_price)) * size * leverage
        pnl_pct = (entry - float(exit_price)) / entry * 100 * leverage

    trade["pnl"] = round(pnl, 2)
    trade["pnl_pct"] = round(pnl_pct, 2)

    if system_compliant is not None:
        trade["system_compliant"] = bool(system_compliant)

    # 自动判定是否按系统出�?    if trade["system_compliant"] is None:
        stop_hit = direction == "long" and float(exit_price) <= trade["stop_loss"]
        stop_hit = stop_hit or (direction == "short" and float(exit_price) >= trade["stop_loss"])
        if stop_hit:
            trade["system_compliant"] = True  # 被止�?= 按系统执�?            trade["exit_reason"] = "止损触发"

    _save(data)
    emoji = "+" if pnl > 0 else ""
    print(f"交易 #{trade_id} 已平�? {emoji}${pnl:,.2f} ({pnl_pct:+.1f}%)")
    print(f"  出场: {exit_price} | 原因: {trade['exit_reason']}")

    # 自动复盘
    closed = [t for t in data["trades"] if t["exit_price"] is not None]
    if len(closed) % 10 == 0 and len(closed) > 0:
        print("\n" + "=" * 50)
        print(f" 已满 {len(closed)} 笔交易，自动阶段复盘")
        print("=" * 50)
        _print_review(closed[-10:], data["reviews"])

    return trade


def _print_review(trades, reviews):
    """打印 10 笔阶段复�?""
    wins = [t for t in trades if t["pnl"] and t["pnl"] > 0]
    losses = [t for t in trades if t["pnl"] and t["pnl"] <= 0]
    compliant = [t for t in trades if t.get("system_compliant")]
    non_compliant = [t for t in trades if t.get("system_compliant") is False]

    win_rate = len(wins) / len(trades) * 100 if trades else 0
    avg_win = sum(t["pnl"] for t in wins) / len(wins) if wins else 0
    avg_loss = sum(t["pnl"] for t in losses) / len(losses) if losses else 0
    total_pnl = sum(t["pnl"] or 0 for t in trades)

    # 最大连�?    max_consecutive_loss = 0
    current_streak = 0
    for t in sorted(trades, key=lambda x: x["open_ts"]):
        if t["pnl"] and t["pnl"] <= 0:
            current_streak += 1
            max_consecutive_loss = max(max_consecutive_loss, current_streak)
        else:
            current_streak = 0

    review = {
        "date": datetime.now(TZ).strftime("%Y-%m-%d %H:%M"),
        "total_trades": len(trades),
        "win_rate": round(win_rate, 1),
        "avg_win": round(avg_win, 2),
        "avg_loss": round(avg_loss, 2),
        "total_pnl": round(total_pnl, 2),
        "max_consecutive_loss": max_consecutive_loss,
        "compliant_rate": round(len(compliant) / len(trades) * 100, 1) if trades else 0,
    }

    print(f"\n  胜率: {win_rate:.0f}% ({len(wins)}/{len(trades)})")
    print(f"  总盈�? ${total_pnl:,.2f}")
    print(f"  平均盈利: ${avg_win:,.2f}  |  平均亏损: ${avg_loss:,.2f}")
    ratio = abs(avg_win / avg_loss) if avg_loss and avg_loss != 0 else 0
    print(f"  盈亏�? {ratio:.1f}:1")
    print(f"  最大连�? {max_consecutive_loss} �?)
    print(f"  系统执行�? {review['compliant_rate']:.0f}%")

    # 盈利单共同特�?    win_reasons = [t["reason"] for t in wins]
    if win_reasons:
        from collections import Counter
        top_win = Counter(win_reasons).most_common(2)
        print(f"\n  盈利信号: {', '.join(f'{r}({c}�?' for r, c in top_win)}")

    loss_reasons = [t["reason"] for t in losses]
    if loss_reasons:
        from collections import Counter
        top_loss = Counter(loss_reasons).most_common(2)
        print(f"  亏损信号: {', '.join(f'{r}({c}�?' for r, c in top_loss)}")

    if non_compliant:
        print(f"\n  �?非系统交�? {len(non_compliant)} �?)
        for t in non_compliant:
            print(f"    #{t['id']} {t['symbol']} {t['direction']} PnL=${t['pnl']:,.0f}")

    reviews.append(review)
    return review


def show_stats():
    """显示全量统计"""
    data = _load()
    trades = data["trades"]
    closed = [t for t in trades if t["exit_price"] is not None]
    open_trades = [t for t in trades if t["exit_price"] is None]

    if not trades:
        print("暂无交易记录")
        return

    wins = [t for t in closed if t["pnl"] and t["pnl"] > 0]
    losses = [t for t in closed if t["pnl"] and t["pnl"] <= 0]

    print(f"\n══�?交易统计 ══�?)
    print(f"  总交�? {len(trades)} �?(持仓�? {len(open_trades)})")
    print(f"  已平�? {len(closed)} �?)
    if closed:
        print(f"  胜率: {len(wins)/len(closed)*100:.0f}% ({len(wins)}�?{len(losses)}�?")
        total = sum(t["pnl"] or 0 for t in closed)
        print(f"  累计盈亏: ${total:,.2f}")
        avg_w = sum(t["pnl"] for t in wins) / len(wins) if wins else 0
        avg_l = sum(t["pnl"] for t in losses) / len(losses) if losses else 0
        print(f"  平均盈利: ${avg_w:,.0f} / 平均亏损: ${avg_l:,.0f}")

        # 按信号类型统�?        from collections import defaultdict
        signal_stats = defaultdict(lambda: {"count": 0, "pnl": 0, "wins": 0})
        for t in closed:
            sig = t["reason"][:20]
            signal_stats[sig]["count"] += 1
            signal_stats[sig]["pnl"] += (t["pnl"] or 0)
            if t["pnl"] and t["pnl"] > 0:
                signal_stats[sig]["wins"] += 1

        print(f"\n  按信号类�?")
        for sig, st in sorted(signal_stats.items(), key=lambda x: -x[1]["pnl"]):
            wr = st["wins"] / st["count"] * 100
            print(f"    {sig}: {st['count']}�?胜率{wr:.0f}% PnL=${st['pnl']:,.0f}")

    if open_trades:
        print(f"\n  当前持仓:")
        for t in open_trades:
            print(f"    #{t['id']} {t['symbol']} {t['direction']} @{t['entry']} "
                  f"止损{t['stop_loss']} 仓位{t['size']}�?)


def list_trades(limit=20):
    """列出最近交�?""
    data = _load()
    trades = data["trades"]
    if not trades:
        print("暂无交易记录")
        return

    print(f"\n══�?最�?{min(limit, len(trades))} 笔交�?══�?)
    print(f"{'ID':>3} {'时间':<16} {'品种':>6} {'方向':>4} {'入场':>8} {'出场':>8} {'盈亏':>10} {'依据'}")
    print("-" * 75)
    for t in trades[-limit:]:
        exit_str = f"{t['exit_price']:.1f}" if t["exit_price"] else "持仓�?
        pnl_str = f"${t['pnl']:,.0f}" if t["pnl"] is not None else "-"
        print(f"{t['id']:>3} {t['open_time']:<16} {t['symbol']:>6} {t['direction']:>4} "
              f"{t['entry']:>8.1f} {exit_str:>8} {pnl_str:>10} {t['reason'][:25]}")


# ─── 交易前验�?────────────────────────────────────

def validate_trade(symbol, direction, entry, stop_loss, capital=20000):
    """
    交易前检�?
    1. 仓位是否超限 (每笔 �?总风险金/10)
    2. 止损是否合理 (不在习惯数字�?
    3. 方向是否与系统一�?    """
    warnings = []

    risk_capital = capital * 0.30  # 30% 总风险金
    per_trade_max = risk_capital / 10

    stop_distance = abs(float(entry) - float(stop_loss))
    # 检查习惯数�?    for bad in [20, 50, 80, 100, 200, 500, 1000]:
        if abs(stop_distance - bad) < 5:
            warnings.append(f"止损距离接近习惯数字 {bad}, 建议避开")

    if stop_distance < 5:
        warnings.append(f"止损距离�?{stop_distance:.1f} 点，可能过近")

    return {
        "risk_capital": risk_capital,
        "per_trade_max": per_trade_max,
        "stop_distance": stop_distance,
        "warnings": warnings,
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == "record":
        if len(sys.argv) < 7:
            print("用法: python trade_log.py record <symbol> <long|short> <entry> <stop> <size> <reason> [leverage]")
            sys.exit(1)
        lev = int(sys.argv[8]) if len(sys.argv) > 8 else 10
        record_trade(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7], lev)

    elif cmd == "close":
        if len(sys.argv) < 4:
            print("用法: python trade_log.py close <id> <exit_price> [reason] [compliant:1|0]")
            sys.exit(1)
        reason = sys.argv[4] if len(sys.argv) > 4 else ""
        compliant = int(sys.argv[5]) if len(sys.argv) > 5 else None
        close_trade(sys.argv[2], sys.argv[3], reason,
                     True if compliant == 1 else (False if compliant == 0 else None))

    elif cmd == "stats":
        show_stats()

    elif cmd == "review":
        data = _load()
        closed = [t for t in data["trades"] if t["exit_price"] is not None]
        last_10 = closed[-10:] if len(closed) >= 10 else closed
        if not last_10:
            print("暂无已平仓交易可复盘")
        else:
            _print_review(last_10, data["reviews"])

    elif cmd == "list":
        limit = int(sys.argv[2]) if len(sys.argv) > 2 else 20
        list_trades(limit)

    elif cmd == "check":
        if len(sys.argv) < 5:
            print("用法: python trade_log.py check <symbol> <entry> <stop> [capital]")
            sys.exit(1)
        capital = int(sys.argv[5]) if len(sys.argv) > 5 else 20000
        result = validate_trade(sys.argv[2], "", sys.argv[3], sys.argv[4], capital)
        print(f"风险�? ${result['risk_capital']:,.0f} | 每笔最�? ${result['per_trade_max']:,.0f}")
        print(f"止损距离: {result['stop_distance']:.1f} �?)
        for w in result["warnings"]:
            print(f"  �?{w}")

    else:
        print(f"未知命令: {cmd}")
